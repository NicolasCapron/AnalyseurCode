Imports System
Imports System.Collections.Generic
Imports System.Drawing
Imports System.IO
Imports System.Linq
Imports System.Text
Imports System.Threading
Imports System.Threading.Tasks
Imports System.Windows.Forms

''' <summary>
''' Code-behind du formulaire principal. Les contrôles sont déclarés dans MainForm.Designer.vb.
''' </summary>
Public Class MainForm

    Private ReadOnly _repo As LogErrorRepository
    Private ReadOnly _entries As New List(Of LogErrorEntry)
    Private _selectionToken As Integer
    Private _cts As CancellationTokenSource
    Private _loading As Boolean

    Public Sub New()
        InitializeComponent()

        ' Initialisations dépendant de la config (non gérables par le concepteur)
        _loading = True
        chkAmsi.Checked = AppConfig.SettingBool("EnableAmsi", True)
        _loading = False

        ' Pas de connexion SQL en mode design
        If Not System.ComponentModel.LicenseManager.UsageMode = System.ComponentModel.LicenseUsageMode.Designtime Then
            _repo = New LogErrorRepository(AppConfig.ConnectionString)
        End If
    End Sub

#Region "Événements formulaire et barre d'outils"

    Private Sub MainForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        Try
            split.SplitterDistance = CInt(ClientSize.Width * 0.55)
        Catch
            ' taille de fenêtre trop petite : on garde la valeur du concepteur
        End Try
    End Sub

    Private Sub MainForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        _cts?.Cancel()
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        _cts?.Cancel()
    End Sub

    Private Sub Options_CheckedChanged(sender As Object, e As EventArgs) Handles chkForce.CheckedChanged, chkAmsi.CheckedChanged
        ResetAnalyses()
    End Sub

#End Region

#Region "Chargement"

    Private Async Sub BtnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        SetBusy(True, "Chargement depuis T_Sys_LogError…")
        Try
            Dim maxRows = CInt(numTop.Value)
            Dim code = txtCode.Text
            Dim filtre = txtFiltre.Text
            Dim list = Await Task.Run(Function() _repo.GetRejected(maxRows, code, filtre))

            _loading = True
            ClearPreview()
            _entries.Clear()
            grid.Rows.Clear()
            Dim keys = AppConfig.FileNameJsonKeys
            For Each en In list
                en.FileName = FileNameExtractor.Extract(en.JsonData, keys)
                en.DeclaredExtension = FileNameExtractor.GetExtension(en.FileName)
                _entries.Add(en)
                Dim idx = grid.Rows.Add()
                grid.Rows(idx).Tag = en
                FillRow(grid.Rows(idx))
            Next
            _loading = False
            SetStatus($"{list.Count} entrée(s) avec binaire chargée(s).")
            UpdateStats()
            If grid.Rows.Count > 0 Then Grid_SelectionChanged(grid, EventArgs.Empty)
        Catch ex As Exception
            _loading = False
            MessageBox.Show(Me, ex.Message, "Erreur de chargement", MessageBoxButtons.OK, MessageBoxIcon.Error)
            SetStatus("Erreur de chargement.")
        Finally
            SetBusy(False)
        End Try
    End Sub

#End Region

#Region "Sélection : analyse + aperçu"

    Private Async Sub Grid_SelectionChanged(sender As Object, e As EventArgs) Handles grid.SelectionChanged
        If _loading Then Return
        Dim row = grid.CurrentRow
        If row Is Nothing Then Return
        Dim en = TryCast(row.Tag, LogErrorEntry)
        If en Is Nothing Then Return

        _selectionToken += 1
        Dim token = _selectionToken
        ClearPreview()
        txtJson.Text = en.JsonData
        txtHex.Text = ""
        txtReport.Text = "Chargement du binaire et analyse…"

        Dim opts = CurrentOptions()
        Dim wantPreview = chkPreview.Checked
        Try
            Dim maxBytes = CLng(AppConfig.SettingInt("MaxBinaryMB", 100)) * 1024L * 1024L
            Dim data = Await Task.Run(Function() _repo.GetBinary(en.Id, maxBytes))
            If token <> _selectionToken Then Return
            txtHex.Text = HexDump(data, 8192)

            If en.Analysis Is Nothing Then
                en.Analysis = Await Task.Run(Function() FileAnalyzer.Analyze(en, data, opts))
                FillRow(row)
                UpdateStats()
                If token <> _selectionToken Then Return
            End If
            Dim a = en.Analysis
            txtReport.Text = a.BuildReport(en)

            If Not wantPreview Then
                ShowPreviewMessage("Aperçu désactivé (case « Aperçu isolé à la sélection »).")
            ElseIf a.IsMalware Then
                ShowPreviewMessage("Fichier détecté par l'antivirus : pas de rendu.")
            ElseIf Not a.Detected.Convertible Then
                ShowPreviewMessage("Pas de rendu pour ce type (" & a.Detected.Label & "). Voir l'onglet Hexadécimal.")
            Else
                ShowPreviewMessage("Rendu dans le processus isolé…")
                Dim ext = a.Detected.CanonicalExtension
                Dim outcome = Await Task.Run(Function() WorkerClient.Run(data, ext, doConvert:=False, doPreview:=True))
                If token <> _selectionToken Then
                    outcome.DisposePreviews()
                    Return
                End If
                ShowPreviews(outcome)
            End If
        Catch ex As Exception
            If token = _selectionToken Then txtReport.Text = "Erreur : " & ex.ToString()
        End Try
    End Sub

    Private Function CurrentOptions() As AnalysisOptions
        Return New AnalysisOptions With {.ForceConversion = chkForce.Checked, .UseAmsi = chkAmsi.Checked}
    End Function

#End Region

#Region "Analyse en lot"

    Private Async Sub BtnAnalyzeAll_Click(sender As Object, e As EventArgs) Handles btnAnalyzeAll.Click
        If grid.Rows.Count = 0 Then Return
        _cts = New CancellationTokenSource()
        Dim ct = _cts.Token
        Dim rows = grid.Rows.Cast(Of DataGridViewRow)().ToList()
        Dim opts = CurrentOptions()
        Dim maxBytes = CLng(AppConfig.SettingInt("MaxBinaryMB", 100)) * 1024L * 1024L

        SetBusy(True, "Analyse en cours…")
        progress.Maximum = rows.Count
        progress.Value = 0
        Try
            For Each row In rows
                If ct.IsCancellationRequested Then Exit For
                Dim en = DirectCast(row.Tag, LogErrorEntry)
                If en.Analysis Is Nothing Then
                    Try
                        en.Analysis = Await Task.Run(Function()
                                                         Dim data = _repo.GetBinary(en.Id, maxBytes)
                                                         Return FileAnalyzer.Analyze(en, data, opts)
                                                     End Function)
                    Catch ex As Exception
                        en.Analysis = AnalysisResult.FromError(en, ex)
                    End Try
                    FillRow(row)
                End If
                progress.Value += 1
                SetStatus($"Analyse {progress.Value}/{rows.Count}…")
            Next
            UpdateStats()
            tabs.SelectedTab = tabStats
            SetStatus(If(ct.IsCancellationRequested, "Analyse interrompue.", "Analyse terminée."))
        Finally
            _cts = Nothing
            SetBusy(False)
        End Try
    End Sub

    Private Sub ResetAnalyses()
        If _loading Then Return
        For Each row As DataGridViewRow In grid.Rows
            DirectCast(row.Tag, LogErrorEntry).Analysis = Nothing
            FillRow(row)
        Next
        UpdateStats()
        SetStatus("Options modifiées : analyses réinitialisées.")
    End Sub

#End Region

#Region "Aperçu"

    Private Sub ShowPreviews(o As WorkerOutcome)
        ClearPreview()
        AddPreviewLabel($"{o.PageCount} page(s), {o.Previews.Count} affichée(s) — rendu en {o.DurationMs:N0} ms dans un processus confiné, transmis en pixels bruts.", Color.White)
        If Not String.IsNullOrEmpty(o.Status) AndAlso o.Status <> "OK" Then AddPreviewLabel("Statut : " & o.Status, Color.Orange)
        For Each m In o.Messages
            AddPreviewLabel("⚠ " & m, Color.Gold)
        Next
        For Each bmp In o.Previews
            previewPanel.Controls.Add(New PictureBox With {
                .Image = bmp, .SizeMode = PictureBoxSizeMode.AutoSize,
                .Margin = New Padding(8), .BorderStyle = BorderStyle.FixedSingle})
        Next
    End Sub

    Private Sub ShowPreviewMessage(text As String)
        ClearPreview()
        AddPreviewLabel(text, Color.White)
    End Sub

    Private Sub AddPreviewLabel(text As String, color As Color)
        previewPanel.Controls.Add(New Label With {
            .Text = text, .AutoSize = True, .ForeColor = color,
            .MaximumSize = New Size(Math.Max(300, previewPanel.ClientSize.Width - 30), 0),
            .Margin = New Padding(8, 6, 8, 2)})
    End Sub

    Private Sub ClearPreview()
        Dim old = previewPanel.Controls.Cast(Of Control)().ToList()
        previewPanel.Controls.Clear()
        For Each c In old
            Dim pb = TryCast(c, PictureBox)
            If pb IsNot Nothing AndAlso pb.Image IsNot Nothing Then pb.Image.Dispose()
            c.Dispose()
        Next
    End Sub

#End Region

#Region "Grille et synthèse"

    Private Sub FillRow(row As DataGridViewRow)
        If row Is Nothing OrElse row.DataGridView Is Nothing Then Return
        Dim en = DirectCast(row.Tag, LogErrorEntry)
        row.Cells(colId.Index).Value = en.Id.ToString("0")
        row.Cells(colDate.Index).Value = en.DateErr
        row.Cells(colHeure.Index).Value = en.HeureErr
        row.Cells(colModule.Index).Value = en.ModuleName
        row.Cells(colFichier.Index).Value = en.FileName
        row.Cells(colExt.Index).Value = en.DeclaredExtension
        row.Cells(colTaille.Index).Value = FormatSize(en.BinarySize)

        Dim analysisCols = {colType, colSignature, colPdfa, colRisques, colAmsi, colDiagnostic}
        Dim a = en.Analysis
        If a Is Nothing Then
            For Each col In analysisCols
                row.Cells(col.Index).Value = Nothing
            Next
            row.DefaultCellStyle.BackColor = Color.Empty
            row.DefaultCellStyle.ForeColor = Color.Empty
            Return
        End If

        row.Cells(colType.Index).Value = a.Detected.Label
        row.Cells(colSignature.Index).Value = If(a.Signature.Ok, "OK", "KO")
        row.Cells(colPdfa.Index).Value = a.ConversionLabel
        row.Cells(colRisques.Index).Value = a.ThreatLabel
        row.Cells(colAmsi.Index).Value = a.Amsi
        row.Cells(colDiagnostic.Index).Value = a.Diagnostic

        If a.IsMalware OrElse a.CriticalCount > 0 Then
            row.DefaultCellStyle.BackColor = Color.FromArgb(255, 200, 200)
            row.DefaultCellStyle.ForeColor = Color.DarkRed
        ElseIf Not a.Signature.Ok Then
            row.DefaultCellStyle.BackColor = Color.MistyRose
            row.DefaultCellStyle.ForeColor = Color.Empty
        ElseIf a.Conversion IsNot Nothing AndAlso a.Conversion.Status = "OK" Then
            row.DefaultCellStyle.BackColor = Color.Honeydew
            row.DefaultCellStyle.ForeColor = Color.Empty
        Else
            row.DefaultCellStyle.BackColor = Color.LightGoldenrodYellow
            row.DefaultCellStyle.ForeColor = Color.Empty
        End If
    End Sub

    Private Sub UpdateStats()
        Dim analyzed = _entries.Where(Function(x) x.Analysis IsNot Nothing).ToList()
        Dim sb As New StringBuilder()
        sb.AppendLine($"{analyzed.Count} fichier(s) analysé(s) sur {_entries.Count} chargé(s).")
        sb.AppendLine()
        If analyzed.Count = 0 Then
            txtStats.Text = sb.ToString()
            Return
        End If

        sb.AppendLine("RÉPARTITION PAR DIAGNOSTIC")
        AppendGroup(sb, analyzed, Function(x) x.Analysis.Diagnostic)
        sb.AppendLine("EXTENSION DÉCLARÉE → TYPE RÉEL")
        AppendGroup(sb, analyzed, Function(x) ExtLabel(x) & " → " & x.Analysis.Detected.Key)
        sb.AppendLine("PAR MODULE")
        AppendGroup(sb, analyzed, Function(x) x.ModuleName)

        sb.AppendLine("INDICATEURS DE RISQUE CRITIQUES")
        Dim crit = analyzed.SelectMany(Function(x) x.Analysis.Findings.
                                           Where(Function(f) f.Level = Severity.Critique).
                                           Select(Function(f) f.Text)).ToList()
        If crit.Count = 0 Then
            sb.AppendLine("  aucun")
        Else
            For Each g In crit.GroupBy(Function(t) t).OrderByDescending(Function(g2) g2.Count())
                sb.AppendLine($"  {g.Count(),5}  {g.Key}")
            Next
        End If
        sb.AppendLine()

        sb.AppendLine("LÉGENDE")
        For Each k In analyzed.Select(Function(x) x.Analysis.Diagnostic).Distinct().OrderBy(Function(x) x)
            Dim help = AnalysisResult.DiagnosticHelp(k)
            If help <> "" Then sb.AppendLine("  " & k & " :" & Environment.NewLine & "      " & help)
        Next
        txtStats.Text = sb.ToString()
    End Sub

    Private Shared Function ExtLabel(x As LogErrorEntry) As String
        Return If(x.DeclaredExtension = "", "(sans ext.)", "." & x.DeclaredExtension)
    End Function

    Private Shared Sub AppendGroup(sb As StringBuilder, items As List(Of LogErrorEntry), keySel As Func(Of LogErrorEntry, String))
        Dim total = items.Count
        For Each g In items.GroupBy(keySel).OrderByDescending(Function(x) x.Count())
            Dim ids = String.Join(", ", g.Take(5).Select(Function(x) x.Id.ToString("0")))
            sb.AppendLine($"  {g.Count(),5}  {g.Count() / total,7:P1}  {g.Key}   (ex. Er_Id {ids})")
        Next
        sb.AppendLine()
    End Sub

    Private Shared Function FormatSize(bytes As Long) As String
        If bytes < 1024 Then Return $"{bytes} o"
        If bytes < 1024L * 1024L Then Return $"{bytes / 1024.0:N0} Ko"
        Return $"{bytes / 1024.0 / 1024.0:N1} Mo"
    End Function

    Private Sub SetBusy(busy As Boolean, Optional message As String = Nothing)
        btnLoad.Enabled = Not busy
        btnAnalyzeAll.Enabled = Not busy
        btnExport.Enabled = Not busy
        chkForce.Enabled = Not busy
        chkAmsi.Enabled = Not busy
        btnCancel.Enabled = busy AndAlso _cts IsNot Nothing
        progress.Visible = busy AndAlso _cts IsNot Nothing
        UseWaitCursor = busy AndAlso _cts Is Nothing
        If message IsNot Nothing Then SetStatus(message)
    End Sub

    Private Sub SetStatus(text As String)
        lblStatus.Text = text
    End Sub

#End Region

#Region "Export CSV"

    Private Sub BtnExport_Click(sender As Object, e As EventArgs) Handles btnExport.Click
        If _entries.Count = 0 Then Return
        Using dlg As New SaveFileDialog With {
            .Filter = "CSV (*.csv)|*.csv",
            .FileName = $"rejets_sanitize_{DateTime.Now:yyyyMMdd_HHmm}.csv"}
            If dlg.ShowDialog(Me) <> DialogResult.OK Then Return

            Dim sb As New StringBuilder()
            sb.AppendLine(String.Join(";", {"Er_Id", "Date", "Heure", "Appli", "Module", "Classe", "Fonction", "Fichier", "ExtDeclaree",
                                            "Taille", "TypeReel", "Signature", "MotifsSignature", "ConversionPdfA", "DetailConversion",
                                            "Risques", "DetailRisques", "AMSI", "Diagnostic", "SHA256"}))
            For Each en In _entries
                Dim a = en.Analysis
                Dim cells As String()
                If a Is Nothing Then
                    cells = {en.Id.ToString("0"), en.DateErr, en.HeureErr, en.Appli, en.ModuleName, en.ClassName, en.FunctionName,
                             en.FileName, en.DeclaredExtension, en.BinarySize.ToString(), "", "", "", "", "", "", "", "", "NON_ANALYSE", ""}
                Else
                    cells = {en.Id.ToString("0"), en.DateErr, en.HeureErr, en.Appli, en.ModuleName, en.ClassName, en.FunctionName,
                             en.FileName, en.DeclaredExtension, en.BinarySize.ToString(), a.Detected.Label,
                             If(a.Signature.Ok, "OK", "KO"), String.Join(" | ", a.Signature.Reasons),
                             a.ConversionLabel, If(a.Conversion Is Nothing, "", String.Join(" | ", a.Conversion.Messages)),
                             a.ThreatLabel, String.Join(" | ", a.Findings.Select(Function(f) f.ToString())),
                             a.Amsi, a.Diagnostic, a.Sha256}
                End If
                sb.AppendLine(String.Join(";", cells.Select(Function(c) Csv(c))))
            Next
            File.WriteAllText(dlg.FileName, sb.ToString(), New UTF8Encoding(True)) ' BOM pour Excel FR
            SetStatus("Export : " & dlg.FileName)
        End Using
    End Sub

    Private Shared Function Csv(s As String) As String
        If s Is Nothing Then Return ""
        Dim v = s.Replace(ControlChars.CrLf, " ").Replace(ControlChars.Lf, " ").Replace(ControlChars.Cr, " ")
        If v.IndexOfAny({";"c, """"c}) >= 0 Then v = """" & v.Replace("""", """""") & """"
        Return v
    End Function

#End Region

End Class
