<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.pnlToolbar = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblTop = New System.Windows.Forms.Label()
        Me.numTop = New System.Windows.Forms.NumericUpDown()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.txtCode = New System.Windows.Forms.TextBox()
        Me.lblFiltre = New System.Windows.Forms.Label()
        Me.txtFiltre = New System.Windows.Forms.TextBox()
        Me.btnLoad = New System.Windows.Forms.Button()
        Me.btnAnalyzeAll = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnExport = New System.Windows.Forms.Button()
        Me.chkForce = New System.Windows.Forms.CheckBox()
        Me.chkPreview = New System.Windows.Forms.CheckBox()
        Me.chkAmsi = New System.Windows.Forms.CheckBox()
        Me.split = New System.Windows.Forms.SplitContainer()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.colId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHeure = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colModule = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFichier = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTaille = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSignature = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPdfa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRisques = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAmsi = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDiagnostic = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tabs = New System.Windows.Forms.TabControl()
        Me.tabDiagnostic = New System.Windows.Forms.TabPage()
        Me.txtReport = New System.Windows.Forms.TextBox()
        Me.tabPreview = New System.Windows.Forms.TabPage()
        Me.previewPanel = New System.Windows.Forms.FlowLayoutPanel()
        Me.tabHex = New System.Windows.Forms.TabPage()
        Me.txtHex = New System.Windows.Forms.TextBox()
        Me.tabJson = New System.Windows.Forms.TabPage()
        Me.txtJson = New System.Windows.Forms.TextBox()
        Me.tabStats = New System.Windows.Forms.TabPage()
        Me.txtStats = New System.Windows.Forms.TextBox()
        Me.statusStrip = New System.Windows.Forms.StatusStrip()
        Me.lblStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.progress = New System.Windows.Forms.ToolStripProgressBar()
        Me.pnlToolbar.SuspendLayout()
        CType(Me.numTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.split, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.split.Panel1.SuspendLayout()
        Me.split.Panel2.SuspendLayout()
        Me.split.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabs.SuspendLayout()
        Me.tabDiagnostic.SuspendLayout()
        Me.tabPreview.SuspendLayout()
        Me.tabHex.SuspendLayout()
        Me.tabJson.SuspendLayout()
        Me.tabStats.SuspendLayout()
        Me.statusStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlToolbar
        '
        Me.pnlToolbar.AutoSize = True
        Me.pnlToolbar.Controls.Add(Me.lblTop)
        Me.pnlToolbar.Controls.Add(Me.numTop)
        Me.pnlToolbar.Controls.Add(Me.lblCode)
        Me.pnlToolbar.Controls.Add(Me.txtCode)
        Me.pnlToolbar.Controls.Add(Me.lblFiltre)
        Me.pnlToolbar.Controls.Add(Me.txtFiltre)
        Me.pnlToolbar.Controls.Add(Me.btnLoad)
        Me.pnlToolbar.Controls.Add(Me.btnAnalyzeAll)
        Me.pnlToolbar.Controls.Add(Me.btnCancel)
        Me.pnlToolbar.Controls.Add(Me.btnExport)
        Me.pnlToolbar.Controls.Add(Me.chkForce)
        Me.pnlToolbar.Controls.Add(Me.chkPreview)
        Me.pnlToolbar.Controls.Add(Me.chkAmsi)
        Me.pnlToolbar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlToolbar.Location = New System.Drawing.Point(0, 0)
        Me.pnlToolbar.Name = "pnlToolbar"
        Me.pnlToolbar.Padding = New System.Windows.Forms.Padding(6, 6, 6, 2)
        Me.pnlToolbar.Size = New System.Drawing.Size(1584, 37)
        Me.pnlToolbar.TabIndex = 0
        '
        'lblTop
        '
        Me.lblTop.AutoSize = True
        Me.lblTop.Margin = New System.Windows.Forms.Padding(3, 7, 0, 0)
        Me.lblTop.Name = "lblTop"
        Me.lblTop.Text = "Lignes max :"
        '
        'numTop
        '
        Me.numTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.numTop.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numTop.Name = "numTop"
        Me.numTop.Size = New System.Drawing.Size(80, 23)
        Me.numTop.TabIndex = 1
        Me.numTop.Value = New Decimal(New Integer() {300, 0, 0, 0})
        '
        'lblCode
        '
        Me.lblCode.AutoSize = True
        Me.lblCode.Margin = New System.Windows.Forms.Padding(8, 7, 0, 0)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Text = "Er_Code :"
        '
        'txtCode
        '
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Size = New System.Drawing.Size(90, 23)
        Me.txtCode.TabIndex = 2
        '
        'lblFiltre
        '
        Me.lblFiltre.AutoSize = True
        Me.lblFiltre.Margin = New System.Windows.Forms.Padding(8, 7, 0, 0)
        Me.lblFiltre.Name = "lblFiltre"
        Me.lblFiltre.Text = "Filtre module/classe/fonction/message :"
        '
        'txtFiltre
        '
        Me.txtFiltre.Name = "txtFiltre"
        Me.txtFiltre.Size = New System.Drawing.Size(180, 23)
        Me.txtFiltre.TabIndex = 3
        '
        'btnLoad
        '
        Me.btnLoad.AutoSize = True
        Me.btnLoad.Margin = New System.Windows.Forms.Padding(6, 2, 0, 0)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.TabIndex = 4
        Me.btnLoad.Text = "Charger"
        Me.btnLoad.UseVisualStyleBackColor = True
        '
        'btnAnalyzeAll
        '
        Me.btnAnalyzeAll.AutoSize = True
        Me.btnAnalyzeAll.Margin = New System.Windows.Forms.Padding(6, 2, 0, 0)
        Me.btnAnalyzeAll.Name = "btnAnalyzeAll"
        Me.btnAnalyzeAll.TabIndex = 5
        Me.btnAnalyzeAll.Text = "Analyser tout"
        Me.btnAnalyzeAll.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.AutoSize = True
        Me.btnCancel.Enabled = False
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(6, 2, 0, 0)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.TabIndex = 6
        Me.btnCancel.Text = "Arrêter"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnExport
        '
        Me.btnExport.AutoSize = True
        Me.btnExport.Margin = New System.Windows.Forms.Padding(6, 2, 0, 0)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.TabIndex = 7
        Me.btnExport.Text = "Exporter CSV"
        Me.btnExport.UseVisualStyleBackColor = True
        '
        'chkForce
        '
        Me.chkForce.AutoSize = True
        Me.chkForce.Margin = New System.Windows.Forms.Padding(12, 6, 3, 0)
        Me.chkForce.Name = "chkForce"
        Me.chkForce.TabIndex = 8
        Me.chkForce.Text = "Forcer la conversion si signature KO (diagnostic)"
        Me.chkForce.UseVisualStyleBackColor = True
        '
        'chkPreview
        '
        Me.chkPreview.AutoSize = True
        Me.chkPreview.Checked = True
        Me.chkPreview.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPreview.Margin = New System.Windows.Forms.Padding(6, 6, 3, 0)
        Me.chkPreview.Name = "chkPreview"
        Me.chkPreview.TabIndex = 9
        Me.chkPreview.Text = "Aperçu isolé à la sélection"
        Me.chkPreview.UseVisualStyleBackColor = True
        '
        'chkAmsi
        '
        Me.chkAmsi.AutoSize = True
        Me.chkAmsi.Checked = True
        Me.chkAmsi.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkAmsi.Margin = New System.Windows.Forms.Padding(6, 6, 3, 0)
        Me.chkAmsi.Name = "chkAmsi"
        Me.chkAmsi.TabIndex = 10
        Me.chkAmsi.Text = "Scan antivirus (AMSI)"
        Me.chkAmsi.UseVisualStyleBackColor = True
        '
        'split
        '
        Me.split.Dock = System.Windows.Forms.DockStyle.Fill
        Me.split.Location = New System.Drawing.Point(0, 37)
        Me.split.Name = "split"
        '
        'split.Panel1
        '
        Me.split.Panel1.Controls.Add(Me.grid)
        '
        'split.Panel2
        '
        Me.split.Panel2.Controls.Add(Me.tabs)
        Me.split.Size = New System.Drawing.Size(1584, 852)
        Me.split.SplitterDistance = 880
        Me.split.TabIndex = 1
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        Me.grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.grid.BackgroundColor = System.Drawing.SystemColors.Window
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colId, Me.colDate, Me.colHeure, Me.colModule, Me.colFichier, Me.colExt, Me.colTaille, Me.colType, Me.colSignature, Me.colPdfa, Me.colRisques, Me.colAmsi, Me.colDiagnostic})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 0)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        Me.grid.RowHeadersVisible = False
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(880, 852)
        Me.grid.TabIndex = 0
        '
        'colId
        '
        Me.colId.HeaderText = "Er_Id"
        Me.colId.Name = "colId"
        Me.colId.ReadOnly = True
        '
        'colDate
        '
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        '
        'colHeure
        '
        Me.colHeure.HeaderText = "Heure"
        Me.colHeure.Name = "colHeure"
        Me.colHeure.ReadOnly = True
        '
        'colModule
        '
        Me.colModule.HeaderText = "Module"
        Me.colModule.Name = "colModule"
        Me.colModule.ReadOnly = True
        '
        'colFichier
        '
        Me.colFichier.HeaderText = "Fichier"
        Me.colFichier.Name = "colFichier"
        Me.colFichier.ReadOnly = True
        '
        'colExt
        '
        Me.colExt.HeaderText = "Ext."
        Me.colExt.Name = "colExt"
        Me.colExt.ReadOnly = True
        '
        'colTaille
        '
        Me.colTaille.HeaderText = "Taille"
        Me.colTaille.Name = "colTaille"
        Me.colTaille.ReadOnly = True
        '
        'colType
        '
        Me.colType.HeaderText = "Type réel"
        Me.colType.Name = "colType"
        Me.colType.ReadOnly = True
        '
        'colSignature
        '
        Me.colSignature.HeaderText = "Signature"
        Me.colSignature.Name = "colSignature"
        Me.colSignature.ReadOnly = True
        '
        'colPdfa
        '
        Me.colPdfa.HeaderText = "PDF/A"
        Me.colPdfa.Name = "colPdfa"
        Me.colPdfa.ReadOnly = True
        '
        'colRisques
        '
        Me.colRisques.HeaderText = "Risques"
        Me.colRisques.Name = "colRisques"
        Me.colRisques.ReadOnly = True
        '
        'colAmsi
        '
        Me.colAmsi.HeaderText = "AMSI"
        Me.colAmsi.Name = "colAmsi"
        Me.colAmsi.ReadOnly = True
        '
        'colDiagnostic
        '
        Me.colDiagnostic.HeaderText = "Diagnostic"
        Me.colDiagnostic.Name = "colDiagnostic"
        Me.colDiagnostic.ReadOnly = True
        '
        'tabs
        '
        Me.tabs.Controls.Add(Me.tabDiagnostic)
        Me.tabs.Controls.Add(Me.tabPreview)
        Me.tabs.Controls.Add(Me.tabHex)
        Me.tabs.Controls.Add(Me.tabJson)
        Me.tabs.Controls.Add(Me.tabStats)
        Me.tabs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabs.Location = New System.Drawing.Point(0, 0)
        Me.tabs.Name = "tabs"
        Me.tabs.SelectedIndex = 0
        Me.tabs.Size = New System.Drawing.Size(700, 852)
        Me.tabs.TabIndex = 0
        '
        'tabDiagnostic
        '
        Me.tabDiagnostic.Controls.Add(Me.txtReport)
        Me.tabDiagnostic.Name = "tabDiagnostic"
        Me.tabDiagnostic.Size = New System.Drawing.Size(692, 824)
        Me.tabDiagnostic.TabIndex = 0
        Me.tabDiagnostic.Text = "Diagnostic"
        Me.tabDiagnostic.UseVisualStyleBackColor = True
        '
        'txtReport
        '
        Me.txtReport.BackColor = System.Drawing.SystemColors.Window
        Me.txtReport.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtReport.Font = New System.Drawing.Font("Consolas", 9.5!)
        Me.txtReport.Multiline = True
        Me.txtReport.Name = "txtReport"
        Me.txtReport.ReadOnly = True
        Me.txtReport.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtReport.TabIndex = 0
        Me.txtReport.WordWrap = False
        '
        'tabPreview
        '
        Me.tabPreview.Controls.Add(Me.previewPanel)
        Me.tabPreview.Name = "tabPreview"
        Me.tabPreview.Size = New System.Drawing.Size(692, 824)
        Me.tabPreview.TabIndex = 1
        Me.tabPreview.Text = "Aperçu (isolé)"
        Me.tabPreview.UseVisualStyleBackColor = True
        '
        'previewPanel
        '
        Me.previewPanel.AutoScroll = True
        Me.previewPanel.BackColor = System.Drawing.Color.DimGray
        Me.previewPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.previewPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.previewPanel.Name = "previewPanel"
        Me.previewPanel.TabIndex = 0
        Me.previewPanel.WrapContents = False
        '
        'tabHex
        '
        Me.tabHex.Controls.Add(Me.txtHex)
        Me.tabHex.Name = "tabHex"
        Me.tabHex.Size = New System.Drawing.Size(692, 824)
        Me.tabHex.TabIndex = 2
        Me.tabHex.Text = "Hexadécimal"
        Me.tabHex.UseVisualStyleBackColor = True
        '
        'txtHex
        '
        Me.txtHex.BackColor = System.Drawing.SystemColors.Window
        Me.txtHex.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtHex.Font = New System.Drawing.Font("Consolas", 9.5!)
        Me.txtHex.Multiline = True
        Me.txtHex.Name = "txtHex"
        Me.txtHex.ReadOnly = True
        Me.txtHex.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtHex.TabIndex = 0
        Me.txtHex.WordWrap = False
        '
        'tabJson
        '
        Me.tabJson.Controls.Add(Me.txtJson)
        Me.tabJson.Name = "tabJson"
        Me.tabJson.Size = New System.Drawing.Size(692, 824)
        Me.tabJson.TabIndex = 3
        Me.tabJson.Text = "Er_JsonData"
        Me.tabJson.UseVisualStyleBackColor = True
        '
        'txtJson
        '
        Me.txtJson.BackColor = System.Drawing.SystemColors.Window
        Me.txtJson.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtJson.Font = New System.Drawing.Font("Consolas", 9.5!)
        Me.txtJson.Multiline = True
        Me.txtJson.Name = "txtJson"
        Me.txtJson.ReadOnly = True
        Me.txtJson.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtJson.TabIndex = 0
        Me.txtJson.WordWrap = False
        '
        'tabStats
        '
        Me.tabStats.Controls.Add(Me.txtStats)
        Me.tabStats.Name = "tabStats"
        Me.tabStats.Size = New System.Drawing.Size(692, 824)
        Me.tabStats.TabIndex = 4
        Me.tabStats.Text = "Synthèse"
        Me.tabStats.UseVisualStyleBackColor = True
        '
        'txtStats
        '
        Me.txtStats.BackColor = System.Drawing.SystemColors.Window
        Me.txtStats.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtStats.Font = New System.Drawing.Font("Consolas", 9.5!)
        Me.txtStats.Multiline = True
        Me.txtStats.Name = "txtStats"
        Me.txtStats.ReadOnly = True
        Me.txtStats.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtStats.TabIndex = 0
        Me.txtStats.WordWrap = False
        '
        'statusStrip
        '
        Me.statusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatus, Me.progress})
        Me.statusStrip.Location = New System.Drawing.Point(0, 889)
        Me.statusStrip.Name = "statusStrip"
        Me.statusStrip.Size = New System.Drawing.Size(1584, 22)
        Me.statusStrip.TabIndex = 2
        '
        'lblStatus
        '
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Spring = True
        Me.lblStatus.Text = "Prêt."
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'progress
        '
        Me.progress.Name = "progress"
        Me.progress.Size = New System.Drawing.Size(250, 16)
        Me.progress.Visible = False
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1584, 911)
        Me.Controls.Add(Me.split)
        Me.Controls.Add(Me.pnlToolbar)
        Me.Controls.Add(Me.statusStrip)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fichiers rejetés par le sanitize — dbo.T_Sys_LogError"
        Me.pnlToolbar.ResumeLayout(False)
        Me.pnlToolbar.PerformLayout()
        CType(Me.numTop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.split.Panel1.ResumeLayout(False)
        Me.split.Panel2.ResumeLayout(False)
        CType(Me.split, System.ComponentModel.ISupportInitialize).EndInit()
        Me.split.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabs.ResumeLayout(False)
        Me.tabDiagnostic.ResumeLayout(False)
        Me.tabDiagnostic.PerformLayout()
        Me.tabPreview.ResumeLayout(False)
        Me.tabHex.ResumeLayout(False)
        Me.tabHex.PerformLayout()
        Me.tabJson.ResumeLayout(False)
        Me.tabJson.PerformLayout()
        Me.tabStats.ResumeLayout(False)
        Me.tabStats.PerformLayout()
        Me.statusStrip.ResumeLayout(False)
        Me.statusStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pnlToolbar As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents lblTop As System.Windows.Forms.Label
    Friend WithEvents numTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblCode As System.Windows.Forms.Label
    Friend WithEvents txtCode As System.Windows.Forms.TextBox
    Friend WithEvents lblFiltre As System.Windows.Forms.Label
    Friend WithEvents txtFiltre As System.Windows.Forms.TextBox
    Friend WithEvents btnLoad As System.Windows.Forms.Button
    Friend WithEvents btnAnalyzeAll As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnExport As System.Windows.Forms.Button
    Friend WithEvents chkForce As System.Windows.Forms.CheckBox
    Friend WithEvents chkPreview As System.Windows.Forms.CheckBox
    Friend WithEvents chkAmsi As System.Windows.Forms.CheckBox
    Friend WithEvents split As System.Windows.Forms.SplitContainer
    Friend WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents colId As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colHeure As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colModule As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFichier As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExt As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTaille As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSignature As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPdfa As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRisques As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAmsi As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDiagnostic As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tabs As System.Windows.Forms.TabControl
    Friend WithEvents tabDiagnostic As System.Windows.Forms.TabPage
    Friend WithEvents txtReport As System.Windows.Forms.TextBox
    Friend WithEvents tabPreview As System.Windows.Forms.TabPage
    Friend WithEvents previewPanel As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents tabHex As System.Windows.Forms.TabPage
    Friend WithEvents txtHex As System.Windows.Forms.TextBox
    Friend WithEvents tabJson As System.Windows.Forms.TabPage
    Friend WithEvents txtJson As System.Windows.Forms.TextBox
    Friend WithEvents tabStats As System.Windows.Forms.TabPage
    Friend WithEvents txtStats As System.Windows.Forms.TextBox
    Friend WithEvents statusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents lblStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents progress As System.Windows.Forms.ToolStripProgressBar

End Class
