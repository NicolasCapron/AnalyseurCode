Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Runtime.InteropServices

''' <summary>
''' Confinement Windows du processus worker :
'''  - limite mémoire et temps CPU,
'''  - interdiction de créer des processus enfants (ActiveProcessLimit = 1),
'''  - restrictions UI (presse-papiers, handles d'autres fenêtres, bureau, paramètres système),
'''  - tout est tué à la fermeture du job (KILL_ON_JOB_CLOSE).
''' </summary>
Public NotInheritable Class JobObject
    Implements IDisposable

    Private Const JobObjectBasicUIRestrictions As Integer = 4
    Private Const JobObjectExtendedLimitInformation As Integer = 9

    Private Const JOB_OBJECT_LIMIT_PROCESS_TIME As UInteger = &H2UI
    Private Const JOB_OBJECT_LIMIT_ACTIVE_PROCESS As UInteger = &H8UI
    Private Const JOB_OBJECT_LIMIT_PROCESS_MEMORY As UInteger = &H100UI
    Private Const JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION As UInteger = &H400UI
    Private Const JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE As UInteger = &H2000UI
    Private Const JOB_OBJECT_UILIMIT_ALL As UInteger = &HFFUI

    Private _handle As IntPtr

    Public Sub New(processMemoryLimitBytes As Long, cpuSeconds As Integer)
        _handle = CreateJobObject(IntPtr.Zero, Nothing)
        If _handle = IntPtr.Zero Then Throw New Win32Exception(Marshal.GetLastWin32Error())

        Dim ext As New JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        ext.BasicLimitInformation.LimitFlags =
            JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE Or
            JOB_OBJECT_LIMIT_PROCESS_MEMORY Or
            JOB_OBJECT_LIMIT_ACTIVE_PROCESS Or
            JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION Or
            JOB_OBJECT_LIMIT_PROCESS_TIME
        ext.BasicLimitInformation.ActiveProcessLimit = 1UI
        ext.BasicLimitInformation.PerProcessUserTimeLimit = CLng(cpuSeconds) * 10000000L ' unités de 100 ns
        ext.ProcessMemoryLimit = New UIntPtr(CULng(processMemoryLimitBytes))
        SetInfo(JobObjectExtendedLimitInformation, ext)

        Dim ui As New JOBOBJECT_BASIC_UI_RESTRICTIONS With {.UIRestrictionsClass = JOB_OBJECT_UILIMIT_ALL}
        SetInfo(JobObjectBasicUIRestrictions, ui)
    End Sub

    Public Sub Assign(p As Process)
        If Not AssignProcessToJobObject(_handle, p.Handle) Then Throw New Win32Exception(Marshal.GetLastWin32Error())
    End Sub

    Private Sub SetInfo(Of T As Structure)(infoClass As Integer, value As T)
        Dim size = Marshal.SizeOf(GetType(T))
        Dim ptr = Marshal.AllocHGlobal(size)
        Try
            Marshal.StructureToPtr(value, ptr, False)
            If Not SetInformationJobObject(_handle, infoClass, ptr, CUInt(size)) Then
                Throw New Win32Exception(Marshal.GetLastWin32Error())
            End If
        Finally
            Marshal.FreeHGlobal(ptr)
        End Try
    End Sub

    Public Sub Dispose() Implements IDisposable.Dispose
        If _handle <> IntPtr.Zero Then
            CloseHandle(_handle) ' => tue tous les processus encore dans le job
            _handle = IntPtr.Zero
        End If
    End Sub

    ' ---- Interop ----

    <StructLayout(LayoutKind.Sequential)>
    Private Structure JOBOBJECT_BASIC_LIMIT_INFORMATION
        Public PerProcessUserTimeLimit As Long
        Public PerJobUserTimeLimit As Long
        Public LimitFlags As UInteger
        Public MinimumWorkingSetSize As UIntPtr
        Public MaximumWorkingSetSize As UIntPtr
        Public ActiveProcessLimit As UInteger
        Public Affinity As UIntPtr
        Public PriorityClass As UInteger
        Public SchedulingClass As UInteger
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Private Structure IO_COUNTERS
        Public ReadOperationCount As ULong
        Public WriteOperationCount As ULong
        Public OtherOperationCount As ULong
        Public ReadTransferCount As ULong
        Public WriteTransferCount As ULong
        Public OtherTransferCount As ULong
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Private Structure JOBOBJECT_EXTENDED_LIMIT_INFORMATION
        Public BasicLimitInformation As JOBOBJECT_BASIC_LIMIT_INFORMATION
        Public IoInfo As IO_COUNTERS
        Public ProcessMemoryLimit As UIntPtr
        Public JobMemoryLimit As UIntPtr
        Public PeakProcessMemoryUsed As UIntPtr
        Public PeakJobMemoryUsed As UIntPtr
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Private Structure JOBOBJECT_BASIC_UI_RESTRICTIONS
        Public UIRestrictionsClass As UInteger
    End Structure

    <DllImport("kernel32.dll", CharSet:=CharSet.Unicode, SetLastError:=True)>
    Private Shared Function CreateJobObject(lpJobAttributes As IntPtr, lpName As String) As IntPtr
    End Function

    <DllImport("kernel32.dll", SetLastError:=True)>
    Private Shared Function SetInformationJobObject(hJob As IntPtr, infoClass As Integer, lpInfo As IntPtr, cbInfo As UInteger) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <DllImport("kernel32.dll", SetLastError:=True)>
    Private Shared Function AssignProcessToJobObject(hJob As IntPtr, hProcess As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <DllImport("kernel32.dll", SetLastError:=True)>
    Private Shared Function CloseHandle(h As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

End Class
