Imports System
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.IO
Imports System.Runtime.InteropServices

''' <summary>
''' Le worker renvoie les aperçus en pixels BRUTS (BGRA 32 bits + largeur/hauteur).
''' L'UI ne décode donc JAMAIS un format d'image (PNG, JPEG…) : même un worker compromis
''' ne peut pas lui transmettre une image piégée, seulement des pixels.
''' </summary>
Public Module RawImage

    Public Const MaxWidth As Integer = 4000
    Public Const MaxHeight As Integer = 10000

    ''' <summary>Côté worker.</summary>
    Public Sub Save(bmp As Bitmap, filePath As String)
        Dim w = bmp.Width
        Dim h = bmp.Height
        Dim bd = bmp.LockBits(New Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb)
        Try
            Dim rowBytes = w * 4
            Dim buffer(rowBytes * h - 1) As Byte
            For y = 0 To h - 1
                Marshal.Copy(IntPtr.Add(bd.Scan0, y * bd.Stride), buffer, y * rowBytes, rowBytes)
            Next
            Using fs = File.Create(filePath), bw As New BinaryWriter(fs)
                bw.Write(w)
                bw.Write(h)
                bw.Write(buffer)
            End Using
        Finally
            bmp.UnlockBits(bd)
        End Try
    End Sub

    ''' <summary>Côté UI : validation stricte puis copie des pixels.</summary>
    Public Function Load(filePath As String) As Bitmap
        Using fs = File.OpenRead(filePath), br As New BinaryReader(fs)
            Dim w = br.ReadInt32()
            Dim h = br.ReadInt32()
            If w <= 0 OrElse h <= 0 OrElse w > MaxWidth OrElse h > MaxHeight Then
                Throw New InvalidDataException($"Dimensions d'aperçu invalides : {w}x{h}")
            End If
            Dim expected = CLng(w) * h * 4
            If fs.Length - 8 <> expected Then Throw New InvalidDataException("Taille de l'aperçu incohérente.")
            Dim buffer = br.ReadBytes(CInt(expected))

            Dim bmp As New Bitmap(w, h, PixelFormat.Format32bppArgb)
            Dim bd = bmp.LockBits(New Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb)
            Try
                For y = 0 To h - 1
                    Marshal.Copy(buffer, y * w * 4, IntPtr.Add(bd.Scan0, y * bd.Stride), w * 4)
                Next
            Finally
                bmp.UnlockBits(bd)
            End Try
            Return bmp
        End Using
    End Function

End Module
