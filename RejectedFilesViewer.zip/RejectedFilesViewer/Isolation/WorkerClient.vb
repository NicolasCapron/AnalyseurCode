Imports System
Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.Web.Script.Serialization

''' <summary>Résultat vu par l'UI (statuts du worker + statuts calculés par le parent).</summary>
Public Class WorkerOutcome
    Public Property Attempted As Boolean
    Public Property Status As String = ""
    Public Property Messages As New List(Of String)
    Public Property PageCount As Integer
    Public Property DurationMs As Long
    Public Property Previews As New List(Of Bitmap)

    Public Shared Function NotAttempted(reason As String) As WorkerOutcome
        Dim o As New WorkerOutcome With {.Attempted = False, .Status = "NON_TENTEE"}
        o.Messages.Add(reason)
        Return o
    End Function

    Public Sub DisposePreviews()
        For Each b In Previews
            b.Dispose()
        Next
        Previews.Clear()
    End Sub
End Class

Public Module WorkerClient

    Private Const HR_VIRUS_INFECTED As Integer = &H800700E1
    Private Const HR_VIRUS_DELETED As Integer = &H800700E2

    ''' <summary>
    ''' Écrit le fichier dans un dossier temporaire dédié, lance ce même exe en mode --worker
    ''' dans un Job Object, attend le résultat puis supprime tout.
    ''' </summary>
    Public Function Run(data As Byte(), contentExt As String, doConvert As Boolean, doPreview As Boolean) As WorkerOutcome
        Dim outcome As New WorkerOutcome With {.Attempted = doConvert}
        Dim sw = Stopwatch.StartNew()
        Dim work = Path.Combine(Path.GetTempPath(), "RFV_" & Guid.NewGuid().ToString("N"))
        Directory.CreateDirectory(work)
        Try
            ' Extension issue du contenu réel, assainie (jamais le nom fourni par l'internaute)
            Dim safeExt = If(Regex.IsMatch(If(contentExt, ""), "^[a-z0-9]{1,5}$"), contentExt, "bin")
            Dim input = Path.Combine(work, "input." & safeExt)

            Try
                File.WriteAllBytes(input, data)
            Catch ex As IOException When ex.HResult = HR_VIRUS_INFECTED OrElse ex.HResult = HR_VIRUS_DELETED
                Return AvBlocked(outcome, sw)
            End Try
            Thread.Sleep(250) ' laisse l'antivirus temps réel réagir
            If Not File.Exists(input) Then Return AvBlocked(outcome, sw)

            Dim timeoutSec = Math.Max(5, AppConfig.SettingInt("WorkerTimeoutSeconds", 60))
            Dim memMb = Math.Max(128, AppConfig.SettingInt("WorkerMemoryMB", 1024))
            Dim exe = Assembly.GetEntryAssembly().Location
            Dim args = $"--worker ""{input}"" ""{work}"" {If(doConvert, 1, 0)} {If(doPreview, 1, 0)}"
            Dim psi As New ProcessStartInfo(exe, args) With {
                .UseShellExecute = False,
                .RedirectStandardInput = True,
                .CreateNoWindow = True,
                .WorkingDirectory = work}

            Dim finished As Boolean
            Dim exitCode As Integer
            Using job As New JobObject(CLng(memMb) * 1024L * 1024L, timeoutSec)
                Using p = Process.Start(psi)
                    Try
                        job.Assign(p)
                    Catch
                        p.Kill()
                        Throw
                    End Try
                    ' Le worker n'ouvre le fichier qu'après ce feu vert, donc forcément déjà confiné
                    p.StandardInput.WriteLine("GO")
                    p.StandardInput.Close()
                    finished = p.WaitForExit(timeoutSec * 1000)
                    If finished Then exitCode = p.ExitCode
                End Using
            End Using ' fermeture du job => kill de tout ce qui tournerait encore

            outcome.DurationMs = sw.ElapsedMilliseconds
            If Not finished Then
                outcome.Status = "TIMEOUT"
                outcome.Messages.Add($"Le traitement a dépassé {timeoutSec} s : processus tué.")
                Return outcome
            End If

            Dim resultPath = Path.Combine(work, "result.json")
            If Not File.Exists(resultPath) OrElse New FileInfo(resultPath).Length > 1024 * 1024 Then
                outcome.Status = "PLANTAGE_WORKER"
                outcome.Messages.Add($"Le worker s'est arrêté sans résultat (code 0x{exitCode:X8}) : plantage du moteur ou limite mémoire ({memMb} Mo) atteinte.")
                Return outcome
            End If

            Dim res = New JavaScriptSerializer().Deserialize(Of WorkerResult)(File.ReadAllText(resultPath, Encoding.UTF8))
            If doConvert Then outcome.Status = If(String.IsNullOrEmpty(res.Status), "ECHEC_CONVERSION", res.Status)
            outcome.PageCount = res.PageCount
            If res.Messages IsNot Nothing Then outcome.Messages.AddRange(res.Messages)

            If res.PreviewFiles IsNot Nothing Then
                For Each f In res.PreviewFiles
                    Dim full = Path.Combine(work, Path.GetFileName(f)) ' aucun chemin dicté par le worker
                    If File.Exists(full) Then
                        Try
                            outcome.Previews.Add(RawImage.Load(full))
                        Catch ex As Exception
                            outcome.Messages.Add("Aperçu rejeté : " & ex.Message)
                        End Try
                    End If
                Next
            End If
            Return outcome
        Finally
            TryDeleteDirectory(work)
        End Try
    End Function

    Private Function AvBlocked(o As WorkerOutcome, sw As Stopwatch) As WorkerOutcome
        o.Attempted = True
        o.Status = "SUPPRIME_PAR_ANTIVIRUS"
        o.DurationMs = sw.ElapsedMilliseconds
        o.Messages.Add("L'antivirus temps réel a bloqué ou supprimé le fichier à l'écriture sur disque.")
        Return o
    End Function

    Private Sub TryDeleteDirectory(dir As String)
        For attempt = 1 To 5
            Try
                If Directory.Exists(dir) Then Directory.Delete(dir, True)
                Return
            Catch
                Thread.Sleep(200)
            End Try
        Next
    End Sub

End Module
