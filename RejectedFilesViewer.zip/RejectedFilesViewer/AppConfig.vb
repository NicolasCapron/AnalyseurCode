Imports System
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Linq

Public NotInheritable Class AppConfig

    Private Sub New()
    End Sub

    Public Shared ReadOnly Property ConnectionString As String
        Get
            Dim cs = ConfigurationManager.ConnectionStrings("LogDb")
            If cs Is Nothing Then Throw New ConfigurationErrorsException("Chaîne de connexion 'LogDb' absente du fichier .config")
            Return cs.ConnectionString
        End Get
    End Property

    Public Shared Function Setting(key As String, defaultValue As String) As String
        Dim v = ConfigurationManager.AppSettings(key)
        Return If(String.IsNullOrWhiteSpace(v), defaultValue, v.Trim())
    End Function

    Public Shared Function SettingInt(key As String, defaultValue As Integer) As Integer
        Dim v As Integer
        Return If(Integer.TryParse(Setting(key, ""), v), v, defaultValue)
    End Function

    Public Shared Function SettingBool(key As String, defaultValue As Boolean) As Boolean
        Dim v As Boolean
        Return If(Boolean.TryParse(Setting(key, ""), v), v, defaultValue)
    End Function

    Public Shared Function SettingList(key As String, defaultValue As String) As String()
        Return Setting(key, defaultValue).
            Split({","c, ";"c}, StringSplitOptions.RemoveEmptyEntries).
            Select(Function(s) s.Trim()).
            Where(Function(s) s.Length > 0).
            ToArray()
    End Function

    Public Shared ReadOnly Property FileNameJsonKeys As String()
        Get
            Return SettingList("FileNameJsonKeys", "FileName,NomFichier,OriginalFileName,Filename,Name")
        End Get
    End Property

    Public Shared ReadOnly Property AllowedExtensions As HashSet(Of String)
        Get
            Return New HashSet(Of String)(
                SettingList("AllowedExtensions", "pdf,jpg,jpeg,png,tif,tiff").Select(Function(s) s.TrimStart("."c).ToLowerInvariant()),
                StringComparer.OrdinalIgnoreCase)
        End Get
    End Property

End Class
