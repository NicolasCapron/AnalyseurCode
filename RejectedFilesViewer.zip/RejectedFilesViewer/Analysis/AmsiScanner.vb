Imports System
Imports System.Runtime.InteropServices

''' <summary>
''' Soumet le buffer à l'antivirus installé (Defender) via AMSI, sans écrire le fichier sur disque.
''' Disponible sur Windows 10 / Server 2016 et plus. La couverture des documents (vs scripts)
''' dépend du moteur : un "Non détecté" n'est pas une garantie.
''' </summary>
Public NotInheritable Class AmsiScanner

    Private Shared _ctx As IntPtr = IntPtr.Zero
    Private Shared _initError As String
    Private Shared ReadOnly _lock As New Object()

    Private Const AMSI_RESULT_DETECTED As Integer = 32768

    Private Sub New()
    End Sub

    Public Shared Function Scan(data As Byte(), contentName As String) As String
        If data Is Nothing OrElse data.Length = 0 Then Return "N/A (vide)"
        SyncLock _lock
            Try
                If _ctx = IntPtr.Zero AndAlso _initError Is Nothing Then
                    Dim hr = AmsiInitialize("RejectedFilesViewer", _ctx)
                    If hr <> 0 Then _initError = $"AmsiInitialize 0x{hr:X8}"
                End If
                If _initError IsNot Nothing Then Return "Indisponible (" & _initError & ")"

                Dim session As IntPtr = IntPtr.Zero
                Dim hrSession = AmsiOpenSession(_ctx, session)
                If hrSession <> 0 Then Return $"Indisponible (AmsiOpenSession 0x{hrSession:X8})"
                Try
                    Dim result As Integer
                    Dim hr = AmsiScanBuffer(_ctx, data, CUInt(data.Length), contentName, session, result)
                    If hr <> 0 Then Return $"Erreur scan 0x{hr:X8}"
                    If result >= AMSI_RESULT_DETECTED Then Return "MALVEILLANT (antivirus)"
                    If result >= &H4000 AndAlso result <= &H4FFF Then Return "Bloqué par stratégie admin"
                    Return "Non détecté"
                Finally
                    AmsiCloseSession(_ctx, session)
                End Try
            Catch ex As DllNotFoundException
                _initError = "amsi.dll absente"
                Return "Indisponible (amsi.dll absente)"
            Catch ex As EntryPointNotFoundException
                _initError = "API AMSI absente"
                Return "Indisponible (API AMSI absente)"
            End Try
        End SyncLock
    End Function

    <DllImport("amsi.dll", CharSet:=CharSet.Unicode)>
    Private Shared Function AmsiInitialize(appName As String, ByRef amsiContext As IntPtr) As Integer
    End Function

    <DllImport("amsi.dll")>
    Private Shared Function AmsiOpenSession(amsiContext As IntPtr, ByRef session As IntPtr) As Integer
    End Function

    <DllImport("amsi.dll")>
    Private Shared Sub AmsiCloseSession(amsiContext As IntPtr, session As IntPtr)
    End Sub

    <DllImport("amsi.dll", CharSet:=CharSet.Unicode)>
    Private Shared Function AmsiScanBuffer(amsiContext As IntPtr, buffer As Byte(), length As UInteger,
                                           contentName As String, session As IntPtr, ByRef result As Integer) As Integer
    End Function

End Class
