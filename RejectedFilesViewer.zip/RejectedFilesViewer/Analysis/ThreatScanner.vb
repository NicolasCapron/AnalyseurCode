Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

Public Enum Severity
    Info
    Avertissement
    Critique
End Enum

Public Class Finding
    Public Property Level As Severity
    Public Property Text As String

    Public Sub New(level As Severity, text As String)
        Me.Level = level
        Me.Text = text
    End Sub

    Public Overrides Function ToString() As String
        Return $"[{Level}] {Text}"
    End Function
End Class

''' <summary>
''' Analyse statique "à la pdfid" : on cherche des marqueurs de contenu actif dans les octets.
''' Aucun parsing par une bibliothèque tierce, donc aucun risque d'exploitation côté UI.
''' Limite : le contenu compressé (flux PDF, parties OOXML) n'est pas inspecté.
''' </summary>
Public Module ThreatScanner

    Private Const SLASH As Byte = 47
    Private Const HASH As Byte = 35

    Private ReadOnly PdfNames As New Dictionary(Of String, Tuple(Of Severity, String))(StringComparer.Ordinal) From {
        {"JavaScript", Tuple.Create(Severity.Critique, "JavaScript embarqué")},
        {"JS", Tuple.Create(Severity.Critique, "Code JavaScript (/JS)")},
        {"Launch", Tuple.Create(Severity.Critique, "Action /Launch (lancement de programme)")},
        {"RichMedia", Tuple.Create(Severity.Critique, "Contenu RichMedia (Flash…)")},
        {"EmbeddedFile", Tuple.Create(Severity.Avertissement, "Fichier(s) joint(s) embarqué(s)")},
        {"OpenAction", Tuple.Create(Severity.Avertissement, "Action automatique à l'ouverture (/OpenAction)")},
        {"AA", Tuple.Create(Severity.Avertissement, "Actions automatiques (/AA)")},
        {"XFA", Tuple.Create(Severity.Avertissement, "Formulaire XFA (interdit en PDF/A)")},
        {"SubmitForm", Tuple.Create(Severity.Avertissement, "Envoi de formulaire vers une URL")},
        {"GoToR", Tuple.Create(Severity.Avertissement, "Lien vers un document distant (/GoToR)")},
        {"GoToE", Tuple.Create(Severity.Avertissement, "Lien vers un document embarqué (/GoToE)")},
        {"ImportData", Tuple.Create(Severity.Avertissement, "Import de données (/ImportData)")},
        {"JBIG2Decode", Tuple.Create(Severity.Avertissement, "Filtre JBIG2 (historiquement exploité)")},
        {"Encrypt", Tuple.Create(Severity.Info, "PDF chiffré : interdit en PDF/A, fait souvent échouer la conversion")},
        {"AcroForm", Tuple.Create(Severity.Info, "Formulaire AcroForm")},
        {"URI", Tuple.Create(Severity.Info, "Liens URI")},
        {"ObjStm", Tuple.Create(Severity.Info, "Flux d'objets compressés : une partie du contenu échappe à ce scan")}
    }

    Public Function Scan(data As Byte(), det As DetectedType) As List(Of Finding)
        Dim list As New List(Of Finding)
        If data Is Nothing OrElse data.Length = 0 Then Return list

        If det.Key = "pdf" Then ScanPdf(data, list)

        Select Case det.Key
            Case "doc", "xls", "ppt", "ole", "msg", "office-encrypted" : ScanOle(data, list)
            Case "docx", "xlsx", "pptx", "docm", "xlsm", "pptm", "zip" : ScanZip(data, list)
            Case "rtf" : ScanRtf(data, list)
            Case "html", "svg", "xml" : ScanMarkup(data, list)
        End Select

        ' --- Contrôles génériques ---
        If det.Key <> "exe" AndAlso ContainsAscii(data, "This program cannot be run in DOS mode") Then
            list.Add(New Finding(Severity.Critique, "Exécutable Windows (PE) embarqué dans le fichier"))
        End If
        If det.Key <> "pdf" Then
            Dim off = IndexOfAscii(data, "%PDF-")
            If off > 0 Then list.Add(New Finding(Severity.Avertissement, $"En-tête %PDF- trouvé à l'offset {off:N0} : fichier polyglotte possible"))
        End If

        Return list
    End Function

    Private Sub ScanPdf(data As Byte(), list As List(Of Finding))
        Dim counts As New Dictionary(Of String, Integer)(StringComparer.Ordinal)
        Dim obfuscated As New HashSet(Of String)(StringComparer.Ordinal)
        Dim sb As New StringBuilder(64)

        ' Lecture des noms PDF (/Nom) avec décodage des échappements #xx (technique d'évasion classique)
        Dim i = 0
        While i < data.Length
            If data(i) <> SLASH Then
                i += 1
                Continue While
            End If
            sb.Clear()
            Dim j = i + 1
            Dim hadHex = False
            While j < data.Length AndAlso sb.Length < 64 AndAlso IsNameChar(data(j))
                If data(j) = HASH AndAlso j + 2 < data.Length AndAlso HexVal(data(j + 1)) >= 0 AndAlso HexVal(data(j + 2)) >= 0 Then
                    sb.Append(ChrW(HexVal(data(j + 1)) * 16 + HexVal(data(j + 2))))
                    hadHex = True
                    j += 3
                Else
                    sb.Append(ChrW(data(j)))
                    j += 1
                End If
            End While
            Dim name = sb.ToString()
            If PdfNames.ContainsKey(name) Then
                Dim n As Integer
                counts.TryGetValue(name, n)
                counts(name) = n + 1
                If hadHex Then obfuscated.Add(name)
            End If
            i = Math.Max(j, i + 1)
        End While

        For Each kv In counts.OrderByDescending(Function(x) PdfNames(x.Key).Item1)
            Dim def = PdfNames(kv.Key)
            list.Add(New Finding(def.Item1, $"{def.Item2} — /{kv.Key} ×{kv.Value}"))
        Next
        If obfuscated.Count > 0 Then
            list.Add(New Finding(Severity.Critique, "Noms PDF obfusqués par encodage #xx : /" & String.Join(", /", obfuscated)))
        End If

        ' Fin de fichier : révisions multiples et données ajoutées après %%EOF
        Dim eofCount = CountAscii(data, "%%EOF")
        If eofCount = 0 Then
            list.Add(New Finding(Severity.Avertissement, "Aucun marqueur %%EOF : PDF tronqué (upload incomplet ?) ou malformé"))
        Else
            If eofCount > 1 Then list.Add(New Finding(Severity.Info, $"{eofCount} révisions (mises à jour incrémentales)"))
            Dim lastEof = LastIndexOfAscii(data, "%%EOF")
            Dim trailing = 0
            For k = lastEof + 5 To data.Length - 1
                If data(k) <> 13 AndAlso data(k) <> 10 AndAlso data(k) <> 32 AndAlso data(k) <> 0 Then trailing += 1
            Next
            If trailing > 64 Then
                list.Add(New Finding(Severity.Avertissement, $"{trailing:N0} octets de données après le dernier %%EOF (charge ajoutée ?)"))
            End If
        End If
    End Sub

    Private Sub ScanOle(data As Byte(), list As List(Of Finding))
        If ContainsUtf16(data, "_VBA_PROJECT") OrElse ContainsAscii(data, "Attribute VB_") Then
            list.Add(New Finding(Severity.Critique, "Macros VBA présentes"))
        End If
        If ContainsUtf16(data, "Ole10Native") Then list.Add(New Finding(Severity.Avertissement, "Objet OLE embarqué (Package / Ole10Native)"))
        If ContainsUtf16(data, "EncryptedPackage") Then list.Add(New Finding(Severity.Avertissement, "Document chiffré par mot de passe : contenu non inspectable, conversion impossible"))
        If ContainsAscii(data, "Equation.3") Then list.Add(New Finding(Severity.Critique, "Objet Equation Editor (Equation.3, CVE-2017-11882)"))
    End Sub

    Private Sub ScanZip(data As Byte(), list As List(Of Finding))
        If ContainsAscii(data, "vbaProject.bin") Then list.Add(New Finding(Severity.Critique, "Macros VBA (vbaProject.bin)"))
        If ContainsAscii(data, "activeX") Then list.Add(New Finding(Severity.Avertissement, "Contrôles ActiveX"))
        If ContainsAscii(data, "/embeddings/") Then list.Add(New Finding(Severity.Avertissement, "Objets embarqués (embeddings)"))
        If ContainsAscii(data, "oleObject") Then list.Add(New Finding(Severity.Avertissement, "Objets OLE"))
        If ContainsAscii(data, "externalLink") Then list.Add(New Finding(Severity.Info, "Liens externes"))
    End Sub

    Private Sub ScanRtf(data As Byte(), list As List(Of Finding))
        If ContainsAscii(data, "\objdata") Then list.Add(New Finding(Severity.Avertissement, "Objet embarqué (\objdata)"))
        If ContainsAscii(data, "\objupdate") Then list.Add(New Finding(Severity.Critique, "Mise à jour automatique d'objet (\objupdate)"))
        If ContainsAsciiIgnoreCase(data, "equation.3") Then list.Add(New Finding(Severity.Critique, "Objet Equation Editor (CVE-2017-11882)"))
    End Sub

    Private Sub ScanMarkup(data As Byte(), list As List(Of Finding))
        If ContainsAsciiIgnoreCase(data, "<script") Then list.Add(New Finding(Severity.Critique, "Balise <script>"))
        If ContainsAsciiIgnoreCase(data, "javascript:") Then list.Add(New Finding(Severity.Avertissement, "URL javascript:"))
        If ContainsAsciiIgnoreCase(data, "onload=") OrElse ContainsAsciiIgnoreCase(data, "onerror=") Then list.Add(New Finding(Severity.Avertissement, "Gestionnaires d'événements (onload/onerror)"))
        If ContainsAsciiIgnoreCase(data, "<foreignobject") Then list.Add(New Finding(Severity.Avertissement, "<foreignObject> (HTML dans SVG)"))
        If ContainsAsciiIgnoreCase(data, "<iframe") Then list.Add(New Finding(Severity.Avertissement, "<iframe>"))
    End Sub

    Private Function IsNameChar(b As Byte) As Boolean
        Select Case b
            Case 0, 9, 10, 12, 13, 32, 40, 41, 60, 62, 91, 93, 123, 125, 47, 37
                Return False
            Case Else
                Return True
        End Select
    End Function

    Private Function HexVal(b As Byte) As Integer
        If b >= 48 AndAlso b <= 57 Then Return b - 48
        If b >= 65 AndAlso b <= 70 Then Return b - 55
        If b >= 97 AndAlso b <= 102 Then Return b - 87
        Return -1
    End Function

End Module
