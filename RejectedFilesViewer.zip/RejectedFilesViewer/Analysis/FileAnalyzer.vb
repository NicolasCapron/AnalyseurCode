Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

Public Class SignatureCheck
    Public Property Ok As Boolean = True
    Public Property Category As String = "OK"
    Public Property Reasons As New List(Of String)
End Class

Public Class AnalysisOptions
    ''' <summary>Tente la conversion même si la signature est KO (diagnostic : "et si on faisait confiance au contenu réel ?").</summary>
    Public Property ForceConversion As Boolean
    Public Property UseAmsi As Boolean
End Class

Public Class AnalysisResult
    Public Property ErrorMessage As String
    Public Property FileName As String = ""
    Public Property DeclaredExt As String = ""
    Public Property Size As Long
    Public Property Sha256 As String = ""
    Public Property Detected As New DetectedType()
    Public Property Signature As New SignatureCheck()
    Public Property Findings As New List(Of Finding)
    Public Property Amsi As String = "Non exécuté"
    Public Property Conversion As WorkerOutcome

    Public ReadOnly Property IsMalware As Boolean
        Get
            Return Amsi IsNot Nothing AndAlso Amsi.StartsWith("MALVEILLANT", StringComparison.Ordinal)
        End Get
    End Property

    Public ReadOnly Property CriticalCount As Integer
        Get
            Return Findings.Where(Function(f) f.Level = Severity.Critique).Count()
        End Get
    End Property

    Public ReadOnly Property WarningCount As Integer
        Get
            Return Findings.Where(Function(f) f.Level = Severity.Avertissement).Count()
        End Get
    End Property

    Public ReadOnly Property ThreatLabel As String
        Get
            If CriticalCount = 0 AndAlso WarningCount = 0 Then Return "—"
            Return $"{CriticalCount} crit. / {WarningCount} avert."
        End Get
    End Property

    Public ReadOnly Property ConversionLabel As String
        Get
            If Conversion Is Nothing Then Return ""
            If Not Conversion.Attempted Then Return "Non tentée"
            Return Conversion.Status
        End Get
    End Property

    Public ReadOnly Property Diagnostic As String
        Get
            If ErrorMessage IsNot Nothing Then Return "ERREUR_ANALYSE"
            If IsMalware Then Return "MALVEILLANT_AV"
            If Not Signature.Ok Then Return "SIG_" & Signature.Category
            If Detected.Key = "office-encrypted" Then Return "OFFICE_PROTEGE_MDP"
            If Conversion Is Nothing OrElse Not Conversion.Attempted Then Return "SIG_OK_CONVERSION_NON_TESTEE"
            If Conversion.Status = "OK" Then Return "OK_AU_REJEU"
            Return "CONV_" & Conversion.Status
        End Get
    End Property

    Public Shared Function FromError(en As LogErrorEntry, ex As Exception) As AnalysisResult
        Return New AnalysisResult With {
            .ErrorMessage = ex.Message,
            .FileName = en.FileName,
            .DeclaredExt = en.DeclaredExtension,
            .Detected = New DetectedType With {.Key = "error", .Label = "?"},
            .Signature = New SignatureCheck With {.Ok = False, .Category = "ERREUR"},
            .Conversion = WorkerOutcome.NotAttempted(ex.Message)}
    End Function

    Public Shared Function DiagnosticHelp(diag As String) As String
        If diag Is Nothing Then Return ""
        If diag = "OK_AU_REJEU" Then Return "La conversion réussit en rejouant le fichier : le rejet en prod vient d'ailleurs (timeout, licence/verrou, version de lib différente, mémoire du pool IIS, fichier tronqué à l'upload…). Compare taille/SHA-256 avec le fichier d'origine."
        If diag.StartsWith("SIG_EXT_INCOHERENTE", StringComparison.Ordinal) Then Return "Le contenu ne correspond pas à l'extension. Souvent légitime (PNG nommé .jpg, export renommé). Piste : se fier au type réel détecté dès qu'il est dans la liste blanche, et renommer avant conversion."
        If diag.StartsWith("SIG_ENTETE_PDF_DECALE", StringComparison.Ordinal) Then Return "PDF valide précédé de quelques octets parasites (scanner, logiciel métier, BOM). Acrobat l'ouvre. Piste : tolérer %PDF- dans les 1024 premiers octets et tronquer le préfixe."
        If diag.StartsWith("SIG_SIGNATURE_INCONNUE", StringComparison.Ordinal) Then Return "Format non reconnu : regarde l'onglet Hexadécimal (fichier corrompu, chiffré, ou format exotique)."
        If diag.StartsWith("SIG_EXT_NON_AUTORISEE", StringComparison.Ordinal) Then Return "Extension cohérente avec le contenu mais absente de la liste blanche (ex. HEIC iPhone, WebP). Décision fonctionnelle : l'ajouter ou mieux informer l'utilisateur."
        If diag.StartsWith("SIG_TYPE_DANGEREUX", StringComparison.Ordinal) Then Return "Contenu intrinsèquement dangereux (exécutable, HTML/SVG) : le rejet est justifié."
        If diag.StartsWith("SIG_VIDE", StringComparison.Ordinal) Then Return "Fichier de 0 octet : upload interrompu ou bug côté client."
        If diag.StartsWith("SIG_SANS_EXTENSION", StringComparison.Ordinal) OrElse diag.StartsWith("SIG_NOM_INCONNU", StringComparison.Ordinal) Then Return "Pas d'extension exploitable (ou nom absent du JSON : vérifie FileNameJsonKeys)."
        If diag = "OFFICE_PROTEGE_MDP" Then Return "Document Office protégé par mot de passe : inconvertible sans le mot de passe. Message utilisateur à prévoir."
        If diag = "CONV_PDF_CHIFFRE" Then Return "PDF avec mot de passe d'ouverture : inconvertible. Message utilisateur à prévoir."
        If diag = "CONV_PDFA_NON_CONFORME" Then Return "Converti mais la validation PDF/A échoue encore (polices non embarquables, transparence, couleurs…). Piste : fallback par rastérisation des pages."
        If diag = "CONV_ECHEC_CONVERSION" Then Return "Le moteur lève une exception : PDF structurellement corrompu ou format non supporté. Piste : réparation (ré-sérialisation) puis rastérisation."
        If diag = "CONV_TIMEOUT" Then Return "Conversion trop longue : fichier lourd (scans haute résolution, milliers de pages) ou boucle dans le moteur."
        If diag = "CONV_PLANTAGE_WORKER" Then Return "Le moteur a planté ou dépassé la limite mémoire : fichier très probablement malformé (voire piégé)."
        If diag = "CONV_SUPPRIME_PAR_ANTIVIRUS" Then Return "L'antivirus temps réel a bloqué l'écriture du fichier : rejet justifié."
        If diag = "MALVEILLANT_AV" Then Return "Détecté par l'antivirus via AMSI : rejet justifié."
        If diag = "SIG_OK_CONVERSION_NON_TESTEE" Then Return "Signature OK, type non pris en charge par le convertisseur de cet outil."
        Return ""
    End Function

    Public Function BuildReport(en As LogErrorEntry) As String
        Dim sb As New StringBuilder()
        sb.AppendLine($"Er_Id {en.Id:0}   |   {en.DateErr} {en.HeureErr}   |   {en.Appli} / {en.ModuleName}   |   Er_Code {en.Code}")
        sb.AppendLine($"{en.ClassName}.{en.FunctionName}")
        sb.AppendLine(New String("─"c, 100))

        If ErrorMessage IsNot Nothing Then
            sb.AppendLine("ERREUR D'ANALYSE : " & ErrorMessage)
            Return sb.ToString()
        End If

        Dim nameTxt = If(String.IsNullOrEmpty(FileName), "(nom introuvable dans Er_JsonData)", FileName)
        Dim extTxt = If(DeclaredExt = "", "(aucune)", "." & DeclaredExt)
        Dim coherent = If(Detected.Extensions.Length = 0, "aucune", "." & String.Join(", .", Detected.Extensions))
        sb.AppendLine($"Fichier            : {nameTxt}")
        sb.AppendLine($"Extension déclarée : {extTxt}")
        sb.AppendLine($"Taille             : {Size:N0} octets")
        sb.AppendLine($"SHA-256            : {Sha256}")
        sb.AppendLine($"Contenu réel       : {Detected.Label}   (extensions cohérentes : {coherent})")
        sb.AppendLine()

        sb.AppendLine("[1] SIGNATURE (magic bytes) vs EXTENSION : " & If(Signature.Ok, "OK", "KO"))
        For Each r In Signature.Reasons
            sb.AppendLine("     • " & r)
        Next
        sb.AppendLine()

        sb.AppendLine("[2] CONVERSION PDF/A : " & ConversionLabel)
        If Conversion IsNot Nothing Then
            If Conversion.DurationMs > 0 Then sb.AppendLine($"     (durée {Conversion.DurationMs:N0} ms, processus isolé)")
            For Each m In Conversion.Messages.Take(40)
                sb.AppendLine("     • " & m)
            Next
        End If
        sb.AppendLine()

        sb.AppendLine("[3] INDICATEURS DE RISQUE (analyse statique)")
        If Findings.Count = 0 Then sb.AppendLine("     aucun")
        For Each f In Findings.OrderByDescending(Function(x) x.Level)
            sb.AppendLine("     • " & f.ToString())
        Next
        sb.AppendLine()

        sb.AppendLine("[4] ANTIVIRUS (AMSI) : " & Amsi)
        sb.AppendLine()
        sb.AppendLine("=> DIAGNOSTIC : " & Diagnostic)
        Dim help = DiagnosticHelp(Diagnostic)
        If help <> "" Then sb.AppendLine("   " & help)
        sb.AppendLine()
        sb.AppendLine("Er_Message d'origine :")
        sb.AppendLine(en.Message)
        Return sb.ToString()
    End Function
End Class

Public Module FileAnalyzer

    Public Function Analyze(en As LogErrorEntry, data As Byte(), opts As AnalysisOptions) As AnalysisResult
        Dim r As New AnalysisResult With {
            .FileName = en.FileName,
            .DeclaredExt = en.DeclaredExtension,
            .Size = data.LongLength,
            .Sha256 = Sha256Hex(data)}

        ' 1) Pur octets, dans le processus UI (aucun parsing)
        r.Detected = FileSignature.Detect(data)
        r.Signature = CheckSignature(r.Detected, r.DeclaredExt, r.FileName)
        r.Findings = ThreatScanner.Scan(data, r.Detected)
        If opts.UseAmsi Then r.Amsi = AmsiScanner.Scan(data, $"T_Sys_LogError_{en.Id:0}")

        ' 2) Conversion : même règle que la prod (seulement si signature OK), sauf mode forcé
        If Not r.Signature.Ok AndAlso Not opts.ForceConversion Then
            r.Conversion = WorkerOutcome.NotAttempted("Signature/extension KO : conversion non tentée (même règle qu'en production).")
        ElseIf r.IsMalware Then
            r.Conversion = WorkerOutcome.NotAttempted("Détecté par l'antivirus : conversion non tentée.")
        ElseIf Not r.Detected.Convertible Then
            r.Conversion = WorkerOutcome.NotAttempted("Type « " & r.Detected.Label & " » non pris en charge par le convertisseur.")
        Else
            ' L'extension utilisée pour le fichier temporaire vient du CONTENU réel, jamais du nom fourni par l'internaute
            r.Conversion = WorkerClient.Run(data, r.Detected.CanonicalExtension, doConvert:=True, doPreview:=False)
        End If
        Return r
    End Function

    Public Function CheckSignature(det As DetectedType, declaredExt As String, fileName As String) As SignatureCheck
        Dim c As New SignatureCheck()
        Dim allowed = AppConfig.AllowedExtensions
        Dim fail = Sub(cat As String, reason As String)
                       If c.Ok Then c.Category = cat
                       c.Ok = False
                       c.Reasons.Add(reason)
                   End Sub

        If det.Key = "empty" Then
            fail("VIDE", "Le fichier est vide (0 octet).")
            Return c
        End If

        If String.IsNullOrEmpty(fileName) Then
            fail("NOM_INCONNU", "Nom de fichier introuvable dans Er_JsonData (paramètre FileNameJsonKeys).")
        ElseIf declaredExt = "" Then
            fail("SANS_EXTENSION", $"Le nom « {fileName} » n'a pas d'extension.")
        End If

        If det.Key = "unknown" Then fail("SIGNATURE_INCONNUE", det.Label)
        If det.IsDangerous Then fail("TYPE_DANGEREUX", "Contenu réel : " & det.Label)
        If det.HeaderOffset > 0 Then
            fail("ENTETE_PDF_DECALE", $"L'en-tête %PDF- est à l'offset {det.HeaderOffset} au lieu de 0.")
        End If

        If declaredExt <> "" AndAlso det.Extensions.Length > 0 AndAlso Not det.Extensions.Contains(declaredExt) Then
            fail($"EXT_INCOHERENTE .{declaredExt}→{det.Key}",
                 $"Extension .{declaredExt} mais contenu réel : {det.Label} (attendu : .{String.Join(", .", det.Extensions)}).")
        End If

        If declaredExt <> "" AndAlso Not allowed.Contains(declaredExt) Then
            fail($"EXT_NON_AUTORISEE .{declaredExt}", $"L'extension .{declaredExt} n'est pas dans la liste blanche (AllowedExtensions).")
        End If

        If c.Ok Then c.Reasons.Add("Signature cohérente avec l'extension et type autorisé.")
        Return c
    End Function

End Module
