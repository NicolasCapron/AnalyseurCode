Imports System
Imports System.Text

Public Class DetectedType
    Public Property Key As String = "unknown"
    Public Property Label As String = ""
    ''' <summary>Extensions cohérentes avec ce contenu. La première sert d'extension canonique.</summary>
    Public Property Extensions As String() = New String() {}
    ''' <summary>Type intrinsèquement dangereux (exécutable, HTML, SVG…).</summary>
    Public Property IsDangerous As Boolean
    ''' <summary>Peut être passé au convertisseur / moteur de rendu.</summary>
    Public Property Convertible As Boolean
    ''' <summary>Pour les PDF : position de l'en-tête %PDF- (0 = normal).</summary>
    Public Property HeaderOffset As Integer

    Public ReadOnly Property CanonicalExtension As String
        Get
            Return If(Extensions.Length > 0, Extensions(0), "bin")
        End Get
    End Property
End Class

''' <summary>Identification du contenu réel par signature (magic bytes), sans aucun parsing de format.</summary>
Public Module FileSignature

    Public Function Detect(data As Byte()) As DetectedType
        If data Is Nothing OrElse data.Length = 0 Then Return Make("empty", "Fichier vide", {})

        ' --- Signatures à offset 0 ---
        If HasAscii(data, 0, "%PDF-") Then Return Make("pdf", "PDF", {"pdf"}, convertible:=True)
        If HasBytes(data, 0, &H89, &H50, &H4E, &H47, &HD, &HA, &H1A, &HA) Then Return Make("png", "Image PNG", {"png"}, convertible:=True)
        If HasBytes(data, 0, &HFF, &HD8, &HFF) Then Return Make("jpeg", "Image JPEG", {"jpg", "jpeg", "jpe", "jfif"}, convertible:=True)
        If HasAscii(data, 0, "GIF87a") OrElse HasAscii(data, 0, "GIF89a") Then Return Make("gif", "Image GIF", {"gif"}, convertible:=True)
        If HasBytes(data, 0, &H49, &H49, &H2A, &H0) OrElse HasBytes(data, 0, &H4D, &H4D, &H0, &H2A) Then Return Make("tiff", "Image TIFF", {"tif", "tiff"}, convertible:=True)
        If HasAscii(data, 0, "RIFF") AndAlso HasAscii(data, 8, "WEBP") Then Return Make("webp", "Image WebP", {"webp"})

        ' Conteneurs ISO BMFF : HEIC (photos iPhone), AVIF, MP4/MOV
        If data.Length >= 12 AndAlso HasAscii(data, 4, "ftyp") Then
            Dim brand = Encoding.ASCII.GetString(data, 8, 4).ToLowerInvariant()
            Select Case brand
                Case "heic", "heix", "hevc", "heim", "heis", "hevm", "hevs", "mif1", "msf1"
                    Return Make("heic", "Image HEIC/HEIF (photo iPhone)", {"heic", "heif"})
                Case "avif", "avis"
                    Return Make("avif", "Image AVIF", {"avif"})
                Case Else
                    Return Make("mp4", "Vidéo/audio ISO (" & brand.Trim() & ")", {"mp4", "mov", "m4a", "3gp"})
            End Select
        End If

        If data.Length >= 26 AndAlso HasAscii(data, 0, "BM") Then
            Dim dib = BitConverter.ToInt32(data, 14)
            If dib = 12 OrElse dib = 40 OrElse dib = 52 OrElse dib = 56 OrElse dib = 108 OrElse dib = 124 Then
                Return Make("bmp", "Image BMP", {"bmp"}, convertible:=True)
            End If
        End If

        ' ZIP / OOXML / OpenDocument
        If HasBytes(data, 0, &H50, &H4B, &H3, &H4) Then
            Dim macro = ContainsAscii(data, "vbaProject.bin")
            If ContainsAscii(data, "word/") Then
                Return If(macro, Make("docm", "Word avec macros (.docm)", {"docm"}), Make("docx", "Word (OOXML)", {"docx"}, convertible:=True))
            End If
            If ContainsAscii(data, "xl/") Then
                Return If(macro, Make("xlsm", "Excel avec macros (.xlsm)", {"xlsm"}), Make("xlsx", "Excel (OOXML)", {"xlsx"}, convertible:=True))
            End If
            If ContainsAscii(data, "ppt/") Then
                Return If(macro, Make("pptm", "PowerPoint avec macros (.pptm)", {"pptm"}), Make("pptx", "PowerPoint (OOXML)", {"pptx"}, convertible:=True))
            End If
            If ContainsAscii(data, "application/vnd.oasis.opendocument.text") Then Return Make("odt", "OpenDocument texte", {"odt"})
            If ContainsAscii(data, "application/vnd.oasis.opendocument.spreadsheet") Then Return Make("ods", "OpenDocument tableur", {"ods"})
            Return Make("zip", "Archive ZIP", {"zip"})
        End If

        ' OLE2 (Office 97-2003, MSG, Office chiffré)
        If HasBytes(data, 0, &HD0, &HCF, &H11, &HE0, &HA1, &HB1, &H1A, &HE1) Then
            If ContainsUtf16(data, "EncryptedPackage") Then
                Return Make("office-encrypted", "Document Office protégé par mot de passe", {"docx", "xlsx", "pptx", "doc", "xls", "ppt"})
            End If
            If ContainsUtf16(data, "WordDocument") Then Return Make("doc", "Word 97-2003", {"doc", "dot"}, convertible:=True)
            If ContainsUtf16(data, "Workbook") OrElse ContainsUtf16(data, "Book") Then Return Make("xls", "Excel 97-2003", {"xls"}, convertible:=True)
            If ContainsUtf16(data, "PowerPoint Document") Then Return Make("ppt", "PowerPoint 97-2003", {"ppt"}, convertible:=True)
            If ContainsUtf16(data, "__substg1.0_") Then Return Make("msg", "Message Outlook (.msg)", {"msg"})
            Return Make("ole", "Conteneur OLE non identifié", {})
        End If

        If HasAscii(data, 0, "{\rtf") Then Return Make("rtf", "RTF (souvent renommé en .doc)", {"rtf"})
        If HasAscii(data, 0, "MZ") Then Return Make("exe", "Exécutable Windows (PE)", {"exe", "dll"}, dangerous:=True)
        If HasBytes(data, 0, &H37, &H7A, &HBC, &HAF, &H27, &H1C) Then Return Make("7z", "Archive 7-Zip", {"7z"})
        If HasAscii(data, 0, "Rar!") Then Return Make("rar", "Archive RAR", {"rar"})
        If HasBytes(data, 0, &H1F, &H8B) Then Return Make("gzip", "Archive GZIP", {"gz"})

        ' PDF dont l'en-tête n'est pas à l'offset 0 (toléré par Acrobat jusqu'à 1024 octets)
        Dim pdfOff = IndexOfAscii(data, "%PDF-", 0, Math.Min(data.Length, 1024))
        If pdfOff > 0 Then
            Dim t = Make("pdf", $"PDF (en-tête décalé de {pdfOff} octets)", {"pdf"}, convertible:=True)
            t.HeaderOffset = pdfOff
            Return t
        End If

        ' Formats texte
        Dim head = Encoding.UTF8.GetString(data, 0, Math.Min(data.Length, 2048)).
                   TrimStart(ChrW(&HFEFF), " "c, ControlChars.Tab, ControlChars.Cr, ControlChars.Lf).
                   ToLowerInvariant()
        If head.Contains("<svg") Then Return Make("svg", "Image SVG (peut contenir du script)", {"svg"}, dangerous:=True)
        If head.StartsWith("<!doctype html", StringComparison.Ordinal) OrElse head.Contains("<html") OrElse head.Contains("<script") Then
            Return Make("html", "Page HTML", {"html", "htm"}, dangerous:=True)
        End If
        If head.StartsWith("<?xml", StringComparison.Ordinal) Then Return Make("xml", "XML", {"xml"})
        If IsMostlyText(data) Then Return Make("text", "Texte brut", {"txt", "csv"})

        Return Make("unknown", "Signature inconnue [" & HexHead(data, 16) & "]", {})
    End Function

    Private Function Make(key As String, label As String, exts As String(),
                          Optional convertible As Boolean = False,
                          Optional dangerous As Boolean = False) As DetectedType
        Return New DetectedType With {.Key = key, .Label = label, .Extensions = exts, .Convertible = convertible, .IsDangerous = dangerous}
    End Function

    Private Function HasBytes(data As Byte(), offset As Integer, ParamArray sig As Integer()) As Boolean
        If data.Length < offset + sig.Length Then Return False
        For i = 0 To sig.Length - 1
            If data(offset + i) <> sig(i) Then Return False
        Next
        Return True
    End Function

    Private Function HasAscii(data As Byte(), offset As Integer, s As String) As Boolean
        If data.Length < offset + s.Length Then Return False
        For i = 0 To s.Length - 1
            If data(offset + i) <> AscW(s(i)) Then Return False
        Next
        Return True
    End Function

End Module
