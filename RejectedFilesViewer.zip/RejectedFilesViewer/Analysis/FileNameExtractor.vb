Imports System
Imports System.Collections.Generic
Imports System.Text.RegularExpressions
Imports System.Web.Script.Serialization

Public Module FileNameExtractor

    ''' <summary>Cherche (récursivement) le nom du fichier dans le JSON logué.</summary>
    Public Function Extract(json As String, keys As String()) As String
        If String.IsNullOrWhiteSpace(json) Then Return ""
        Try
            Dim ser As New JavaScriptSerializer() With {.MaxJsonLength = Integer.MaxValue}
            Dim found = FindKey(ser.DeserializeObject(json), keys, 0)
            If Not String.IsNullOrEmpty(found) Then Return OnlyName(found)
        Catch
            ' JSON tronqué (LEFT 8000) ou invalide : on tente une regex
        End Try

        For Each k In keys
            Dim m = Regex.Match(json, """" & Regex.Escape(k) & """\s*:\s*""([^""]+)""", RegexOptions.IgnoreCase)
            If m.Success Then Return OnlyName(Regex.Unescape(m.Groups(1).Value))
        Next
        Return ""
    End Function

    Private Function FindKey(node As Object, keys As String(), depth As Integer) As String
        If node Is Nothing OrElse depth > 10 Then Return ""

        Dim dict = TryCast(node, Dictionary(Of String, Object))
        If dict IsNot Nothing Then
            For Each k In keys
                For Each kv In dict
                    If String.Equals(kv.Key, k, StringComparison.OrdinalIgnoreCase) AndAlso TypeOf kv.Value Is String Then
                        Return CStr(kv.Value)
                    End If
                Next
            Next
            For Each kv In dict
                Dim r = FindKey(kv.Value, keys, depth + 1)
                If r <> "" Then Return r
            Next
            Return ""
        End If

        Dim arr = TryCast(node, Object())
        If arr IsNot Nothing Then
            For Each it In arr
                Dim r = FindKey(it, keys, depth + 1)
                If r <> "" Then Return r
            Next
        End If
        Return ""
    End Function

    Private Function OnlyName(value As String) As String
        Dim v = value.Trim()
        Dim idx = Math.Max(v.LastIndexOf("\"c), v.LastIndexOf("/"c))
        Return If(idx >= 0, v.Substring(idx + 1), v)
    End Function

    ''' <summary>Extension en minuscules, sans le point. Ne lève jamais d'exception (contrairement à Path.GetExtension).</summary>
    Public Function GetExtension(fileName As String) As String
        If String.IsNullOrWhiteSpace(fileName) Then Return ""
        Dim name = fileName.Trim().TrimEnd("."c, " "c)
        Dim idx = name.LastIndexOf("."c)
        If idx < 0 OrElse idx = name.Length - 1 Then Return ""
        Return name.Substring(idx + 1).ToLowerInvariant()
    End Function

End Module
