Imports System
Imports System.Security.Cryptography
Imports System.Text

''' <summary>
''' Recherche et affichage sur tableaux d'octets. Aucune bibliothèque de parsing :
''' l'UI ne fait que de la comparaison d'octets sur le fichier suspect.
''' </summary>
Public Module ByteUtil

    Public Function Ascii(s As String) As Byte()
        Return Encoding.ASCII.GetBytes(s)
    End Function

    Public Function Utf16(s As String) As Byte()
        Return Encoding.Unicode.GetBytes(s)
    End Function

    Public Function IndexOf(data As Byte(), pattern As Byte(), Optional start As Integer = 0, Optional endExclusive As Integer = -1) As Integer
        If data Is Nothing OrElse pattern Is Nothing OrElse pattern.Length = 0 Then Return -1
        Dim limit = If(endExclusive < 0, data.Length, Math.Min(endExclusive, data.Length))
        Dim last = limit - pattern.Length
        Dim first = pattern(0)
        Dim i = Math.Max(0, start)
        While i <= last
            i = Array.IndexOf(data, first, i, last - i + 1)
            If i < 0 Then Return -1
            Dim ok = True
            For j = 1 To pattern.Length - 1
                If data(i + j) <> pattern(j) Then
                    ok = False
                    Exit For
                End If
            Next
            If ok Then Return i
            i += 1
        End While
        Return -1
    End Function

    Public Function IndexOfAscii(data As Byte(), s As String, Optional start As Integer = 0, Optional endExclusive As Integer = -1) As Integer
        Return IndexOf(data, Ascii(s), start, endExclusive)
    End Function

    Public Function ContainsAscii(data As Byte(), s As String) As Boolean
        Return IndexOf(data, Ascii(s)) >= 0
    End Function

    Public Function ContainsUtf16(data As Byte(), s As String) As Boolean
        Return IndexOf(data, Utf16(s)) >= 0
    End Function

    Public Function CountAscii(data As Byte(), s As String) As Integer
        Dim p = Ascii(s)
        Dim n = 0
        Dim i = IndexOf(data, p)
        While i >= 0
            n += 1
            i = IndexOf(data, p, i + p.Length)
        End While
        Return n
    End Function

    Public Function LastIndexOfAscii(data As Byte(), s As String) As Integer
        Dim p = Ascii(s)
        For i = data.Length - p.Length To 0 Step -1
            Dim ok = True
            For j = 0 To p.Length - 1
                If data(i + j) <> p(j) Then
                    ok = False
                    Exit For
                End If
            Next
            If ok Then Return i
        Next
        Return -1
    End Function

    Public Function ContainsAsciiIgnoreCase(data As Byte(), s As String) As Boolean
        Dim p = Ascii(s.ToLowerInvariant())
        For i = 0 To data.Length - p.Length
            Dim ok = True
            For j = 0 To p.Length - 1
                If Lower(data(i + j)) <> p(j) Then
                    ok = False
                    Exit For
                End If
            Next
            If ok Then Return True
        Next
        Return False
    End Function

    Private Function Lower(b As Byte) As Byte
        Return If(b >= 65 AndAlso b <= 90, CByte(b + 32), b)
    End Function

    Public Function IsMostlyText(data As Byte()) As Boolean
        Dim n = Math.Min(data.Length, 8192)
        If n = 0 Then Return False
        Dim bad = 0
        For i = 0 To n - 1
            Dim b = data(i)
            If b = 0 Then Return False
            If b < 9 OrElse (b > 13 AndAlso b < 32 AndAlso b <> 27) Then bad += 1
        Next
        Return bad <= n \ 100
    End Function

    Public Function HexHead(data As Byte(), count As Integer) As String
        Dim n = Math.Min(data.Length, count)
        Dim sb As New StringBuilder()
        For i = 0 To n - 1
            If i > 0 Then sb.Append(" "c)
            sb.Append(data(i).ToString("X2"))
        Next
        Return sb.ToString()
    End Function

    Public Function HexDump(data As Byte(), maxBytes As Integer) As String
        If data Is Nothing OrElse data.Length = 0 Then Return "(vide)"
        Dim n = Math.Min(data.Length, maxBytes)
        Dim sb As New StringBuilder(n * 5)
        For off = 0 To n - 1 Step 16
            sb.Append(off.ToString("X8")).Append("  ")
            For i = 0 To 15
                If off + i < n Then
                    sb.Append(data(off + i).ToString("X2")).Append(" "c)
                Else
                    sb.Append("   ")
                End If
                If i = 7 Then sb.Append(" "c)
            Next
            sb.Append(" |")
            For i = 0 To 15
                If off + i >= n Then Exit For
                Dim b = data(off + i)
                sb.Append(If(b >= 32 AndAlso b < 127, ChrW(b), "."c))
            Next
            sb.AppendLine("|")
        Next
        If data.Length > n Then sb.AppendLine($"… {data.Length - n:N0} octets supplémentaires non affichés")
        Return sb.ToString()
    End Function

    Public Function Sha256Hex(data As Byte()) As String
        Using sha = SHA256.Create()
            Return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "").ToLowerInvariant()
        End Using
    End Function

End Module
