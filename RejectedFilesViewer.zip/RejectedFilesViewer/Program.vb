Imports System
Imports System.Windows.Forms

Public Module Program

    <STAThread>
    Public Function Main(args As String()) As Integer
        ' Mode worker : processus enfant, placé dans un Job Object, seul à manipuler
        ' réellement le fichier suspect avec le moteur PDF (conversion + rendu).
        If args IsNot Nothing AndAlso args.Length > 0 AndAlso args(0) = "--worker" Then
            Return WorkerHost.Run(args)
        End If

        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)
        Application.Run(New MainForm())
        Return 0
    End Function

End Module
