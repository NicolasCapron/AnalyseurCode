# RejectedFilesViewer

Outil WinForms (VB.NET, .NET Framework 4.8, x64) qui relit les fichiers rejetés par le sanitize
(stockés dans `dbo.T_Sys_LogError.Er_Binary`), rejoue les deux étapes et prévisualise sans risque.

## Mise en route
1. `App.config` : chaîne `LogDb` (compte SQL en lecture seule), `FileNameJsonKeys`, `AllowedExtensions`, `ApryseLicenseKey`.
2. `.vbproj` : référencer le même package/DLL Apryse que la prod.
3. `Worker/ApryseSanitizer.vb` : idéalement, remplacer le corps de `ConvertToPdfA` par l'appel à la vraie méthode de sanitize.

## Ce que fait chaque entrée
1. **Signature vs extension** : détection du type réel par magic bytes (processus UI, comparaison d'octets uniquement).
2. **Conversion PDF/A** : seulement si l'étape 1 est OK (comme en prod), ou forcée via la case « diagnostic ».
3. **Indicateurs de risque** : JavaScript/Launch/OpenAction PDF (avec dés-obfuscation `#xx`), macros, objets OLE, PE embarqué, données après `%%EOF`…
4. **AMSI** : scan du buffer en mémoire par l'antivirus installé.

## Sécurité de l'aperçu
- L'UI ne parse jamais le fichier : seulement des comparaisons d'octets et un dump hexadécimal.
- Conversion et rendu tournent dans un processus enfant (même exe, `--worker`) placé dans un **Job Object** :
  limite mémoire et CPU, pas de processus enfant, restrictions UI (presse-papiers, fenêtres), kill garanti.
- Le worker ne démarre qu'après avoir été placé dans le job (handshake `GO`).
- Le fichier temporaire porte l'extension du contenu réel, dans un dossier dédié supprimé après usage.
- Les aperçus reviennent en **pixels BGRA bruts** : l'UI ne décode aucun format d'image.
- JavaScript PDF désactivé dans le moteur (`PDFNet.EnableJavaScript(False)`).
- Recommandé : exécuter l'outil sur un poste ou une VM d'analyse, sous un compte non administrateur.
