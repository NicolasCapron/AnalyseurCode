Imports System
Imports System.IO
Imports pdftron
Imports pdftron.PDF
Imports pdftron.PDF.PDFA
Imports pdftron.SDF

''' <summary>
''' Implémentation de RÉFÉRENCE basée sur Apryse (PDFNet).
'''
''' >>> IMPORTANT : pour savoir pourquoi TA prod rejette, remplace le corps de ConvertToPdfA
''' >>> par l'appel à ta vraie méthode de sanitize (même DLL, même version, mêmes options).
''' >>> Ce code ne tourne QUE dans le processus worker confiné.
''' </summary>
Public Class ApryseSanitizer
    Implements ISanitizer

    Public Sub Initialize() Implements ISanitizer.Initialize
        ' Si ta prod passe par PDFNetLoader ou une init centralisée, réutilise-la ici.
        PDFNet.Initialize(AppConfig.Setting("ApryseLicenseKey", ""))
        PDFNet.EnableJavaScript(False) ' défense en profondeur : aucun JavaScript PDF exécuté
    End Sub

    Public Sub ConvertToPdfA(inputPath As String, workDir As String, res As WorkerResult) Implements ISanitizer.ConvertToPdfA
        res.Attempted = True
        Dim conformance = GetConformance()
        Dim level = AppConfig.Setting("PdfaConformance", "2B")
        Dim pdfPath = inputPath

        ' Étape 1 : non-PDF -> PDF, ou contrôle d'ouverture du PDF
        If Not IsPdf(inputPath) Then
            pdfPath = Path.Combine(workDir, "etape1.pdf")
            Using doc As New PDFDoc()
                pdftron.PDF.Convert.ToPdf(doc, inputPath)
                res.PageCount = doc.GetPageCount()
                doc.Save(pdfPath, SDFDoc.SaveOptions.e_remove_unused)
            End Using
            res.Messages.Add("Étape 1 : conversion vers PDF réussie.")
        Else
            Using doc As New PDFDoc(inputPath)
                If Not doc.InitSecurityHandler() Then
                    res.Status = "PDF_CHIFFRE"
                    res.Messages.Add("PDF protégé par un mot de passe d'ouverture : inconvertible sans le mot de passe.")
                    Return
                End If
                If doc.IsEncrypted() Then
                    res.Messages.Add("PDF chiffré (restrictions de droits sans mot de passe d'ouverture) : chiffrement interdit en PDF/A.")
                End If
                res.PageCount = doc.GetPageCount()
            End Using
        End If

        ' Étape 2 : PDF -> PDF/A
        Dim pdfaPath = Path.Combine(workDir, "pdfa.pdf")
        Dim conv As New PDFACompliance(True, pdfPath, Nothing, conformance, Nothing, 10, False)
        Try
            Dim n = conv.GetErrorCount()
            If n > 0 Then res.Messages.Add($"Original : {n} non-conformité(s) PDF/A (corrigées si possible) :")
            For i = 0 To Math.Min(n, 25) - 1
                res.Messages.Add("   - " & PDFACompliance.GetPDFAErrorMessage(conv.GetError(i)))
            Next
            conv.SaveAs(pdfaPath, False)
        Finally
            DisposeIfPossible(conv)
        End Try

        ' Étape 3 : re-validation du résultat
        Dim check As New PDFACompliance(False, pdfaPath, Nothing, conformance, Nothing, 10, False)
        Try
            Dim n = check.GetErrorCount()
            If n = 0 Then
                res.Status = "OK"
                res.Messages.Add("Étape 3 : résultat validé PDF/A-" & level & ".")
            Else
                res.Status = "PDFA_NON_CONFORME"
                res.Messages.Add($"Étape 3 : {n} non-conformité(s) subsistent après conversion :")
                For i = 0 To Math.Min(n, 25) - 1
                    res.Messages.Add("   - " & PDFACompliance.GetPDFAErrorMessage(check.GetError(i)))
                Next
            End If
        Finally
            DisposeIfPossible(check)
        End Try
    End Sub

    Public Sub RenderPreview(inputPath As String, workDir As String, res As WorkerResult) Implements ISanitizer.RenderPreview
        Dim maxPages = Math.Max(1, AppConfig.SettingInt("PreviewMaxPages", 3))
        Dim maxWidth = Math.Max(200, AppConfig.SettingInt("PreviewMaxWidth", 1000))

        Using doc = OpenAsPdf(inputPath)
            If Not doc.InitSecurityHandler() Then
                res.Messages.Add("Aperçu impossible : PDF protégé par mot de passe.")
                Return
            End If
            res.PageCount = doc.GetPageCount()

            Dim draw As New PDFDraw()
            Try
                For i = 1 To Math.Min(res.PageCount, maxPages)
                    Dim page = doc.GetPage(i)
                    Dim widthPt = Math.Max(1.0, page.GetPageWidth())
                    Dim dpi = Math.Max(10.0, Math.Min(110.0, maxWidth * 72.0 / widthPt))
                    draw.SetDPI(dpi)
                    Using bmp As System.Drawing.Bitmap = draw.GetBitmap(page)
                        Dim name = $"page{i}.raw"
                        RawImage.Save(bmp, Path.Combine(workDir, name))
                        res.PreviewFiles.Add(name)
                    End Using
                Next
            Finally
                DisposeIfPossible(draw)
            End Try
        End Using
    End Sub

    Private Shared Function OpenAsPdf(inputPath As String) As PDFDoc
        If IsPdf(inputPath) Then Return New PDFDoc(inputPath)
        Dim doc As New PDFDoc()
        pdftron.PDF.Convert.ToPdf(doc, inputPath) ' images, Office…
        Return doc
    End Function

    Private Shared Function IsPdf(p As String) As Boolean
        Return Path.GetExtension(p).Equals(".pdf", StringComparison.OrdinalIgnoreCase)
    End Function

    Private Shared Function GetConformance() As PDFACompliance.Conformance
        Select Case AppConfig.Setting("PdfaConformance", "2B").ToUpperInvariant()
            Case "1A" : Return PDFACompliance.Conformance.e_Level1A
            Case "1B" : Return PDFACompliance.Conformance.e_Level1B
            Case "2A" : Return PDFACompliance.Conformance.e_Level2A
            Case "2U" : Return PDFACompliance.Conformance.e_Level2U
            Case "3A" : Return PDFACompliance.Conformance.e_Level3A
            Case "3B" : Return PDFACompliance.Conformance.e_Level3B
            Case "3U" : Return PDFACompliance.Conformance.e_Level3U
            Case Else : Return PDFACompliance.Conformance.e_Level2B
        End Select
    End Function

    Private Shared Sub DisposeIfPossible(o As Object)
        Dim d = TryCast(o, IDisposable)
        If d IsNot Nothing Then d.Dispose()
    End Sub

End Class
