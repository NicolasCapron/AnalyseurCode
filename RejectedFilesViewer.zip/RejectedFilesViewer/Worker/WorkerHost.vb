Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Text
Imports System.Web.Script.Serialization

''' <summary>Résultat sérialisé par le worker dans result.json.</summary>
Public Class WorkerResult
    Public Property Attempted As Boolean
    ''' <summary>OK | PDF_CHIFFRE | PDFA_NON_CONFORME | ECHEC_CONVERSION | ERREUR_WORKER</summary>
    Public Property Status As String = ""
    Public Property PageCount As Integer
    Public Property Messages As New List(Of String)
    ''' <summary>Noms (sans chemin) des fichiers .raw d'aperçu écrits dans le dossier de travail.</summary>
    Public Property PreviewFiles As New List(Of String)
End Class

''' <summary>
''' Point de branchement de TON sanitize de production.
''' Pour un diagnostic fidèle, ConvertToPdfA doit appeler exactement le même code que la prod.
''' </summary>
Public Interface ISanitizer
    Sub Initialize()
    Sub ConvertToPdfA(inputPath As String, workDir As String, res As WorkerResult)
    Sub RenderPreview(inputPath As String, workDir As String, res As WorkerResult)
End Interface

''' <summary>Code exécuté dans le processus enfant confiné.</summary>
Public Module WorkerHost

    Public Function Run(args As String()) As Integer
        ' Attend que le parent nous ait placé dans le Job Object avant de toucher au fichier
        If Console.In.ReadLine() <> "GO" Then Return 3
        If args.Length < 5 Then Return 2

        Dim input = args(1)
        Dim work = args(2)
        Dim doConvert = args(3) = "1"
        Dim doPreview = args(4) = "1"
        Dim res As New WorkerResult()

        Try
            Dim sanitizer As ISanitizer = New ApryseSanitizer()
            sanitizer.Initialize()

            If doConvert Then
                res.Attempted = True
                Try
                    sanitizer.ConvertToPdfA(input, work, res)
                Catch ex As Exception
                    res.Status = "ECHEC_CONVERSION"
                    res.Messages.Add(Describe(ex))
                End Try
            End If

            If doPreview Then
                Try
                    sanitizer.RenderPreview(input, work, res)
                Catch ex As Exception
                    res.Messages.Add("Aperçu impossible : " & Describe(ex))
                End Try
            End If
        Catch ex As Exception
            res.Status = "ERREUR_WORKER"
            res.Messages.Add(Describe(ex))
        End Try

        File.WriteAllText(Path.Combine(work, "result.json"), New JavaScriptSerializer().Serialize(res), Encoding.UTF8)
        Return 0
    End Function

    Private Function Describe(ex As Exception) As String
        Dim msg = ex.GetType().Name & " : " & ex.Message
        If ex.InnerException IsNot Nothing Then msg &= " | " & ex.InnerException.Message
        Return If(msg.Length > 1500, msg.Substring(0, 1500) & "…", msg)
    End Function

End Module
