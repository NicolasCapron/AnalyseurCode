Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.SqlClient

Public Class LogErrorEntry
    Public Property Id As Decimal
    Public Property Code As String
    Public Property DateErr As String
    Public Property HeureErr As String
    Public Property Appli As String
    Public Property ModuleName As String
    Public Property ClassName As String
    Public Property FunctionName As String
    Public Property Message As String
    Public Property JsonData As String
    Public Property BinarySize As Long

    ' Calculés côté client
    Public Property FileName As String = ""
    Public Property DeclaredExtension As String = ""
    Public Property Analysis As AnalysisResult
End Class

Public Class LogErrorRepository

    Private ReadOnly _cs As String

    Public Sub New(connectionString As String)
        _cs = connectionString
    End Sub

    ''' <summary>
    ''' Liste les erreurs qui ont un binaire attaché. Le binaire lui-même n'est PAS chargé ici
    ''' (seulement sa taille), pour garder la liste légère.
    ''' </summary>
    Public Function GetRejected(maxRows As Integer, errCode As String, filter As String) As List(Of LogErrorEntry)
        Const sql As String = "
SELECT TOP (@top)
    Er_Id, Er_Code, Er_dError, Er_hError, Er_Appli, Er_Module, Er_Class, Er_Function,
    LEFT(Er_Message, 2000)  AS Er_Message,
    LEFT(Er_JsonData, 8000) AS Er_JsonData,
    DATALENGTH(Er_Binary)   AS BinSize
FROM dbo.T_Sys_LogError
WHERE DATALENGTH(Er_Binary) > 0
  AND (@code IS NULL OR Er_Code = @code)
  AND (@filtre IS NULL
       OR Er_Module   LIKE @filtre
       OR Er_Class    LIKE @filtre
       OR Er_Function LIKE @filtre
       OR Er_Message  LIKE @filtre)
ORDER BY Er_Id DESC;"

        Dim list As New List(Of LogErrorEntry)
        Using cn As New SqlConnection(_cs), cmd As New SqlCommand(sql, cn)
            cmd.CommandTimeout = 120
            cmd.Parameters.Add("@top", SqlDbType.Int).Value = maxRows
            cmd.Parameters.Add("@code", SqlDbType.VarChar, 10).Value =
                If(String.IsNullOrWhiteSpace(errCode), CObj(DBNull.Value), errCode.Trim())
            cmd.Parameters.Add("@filtre", SqlDbType.VarChar, 210).Value =
                If(String.IsNullOrWhiteSpace(filter), CObj(DBNull.Value), "%" & filter.Trim() & "%")
            cn.Open()
            Using rd = cmd.ExecuteReader()
                While rd.Read()
                    list.Add(New LogErrorEntry With {
                        .Id = rd.GetDecimal(0),
                        .Code = S(rd, 1),
                        .DateErr = S(rd, 2),
                        .HeureErr = S(rd, 3),
                        .Appli = S(rd, 4),
                        .ModuleName = S(rd, 5),
                        .ClassName = S(rd, 6),
                        .FunctionName = S(rd, 7),
                        .Message = S(rd, 8),
                        .JsonData = S(rd, 9),
                        .BinarySize = If(rd.IsDBNull(10), 0L, Convert.ToInt64(rd.GetValue(10)))
                    })
                End While
            End Using
        End Using
        Return list
    End Function

    ''' <summary>Charge le binaire d'une entrée (refusé au-delà de maxBytes).</summary>
    Public Function GetBinary(id As Decimal, maxBytes As Long) As Byte()
        Const sql As String = "
SELECT DATALENGTH(Er_Binary),
       CASE WHEN DATALENGTH(Er_Binary) <= @max THEN Er_Binary END
FROM dbo.T_Sys_LogError
WHERE Er_Id = @id;"

        Using cn As New SqlConnection(_cs), cmd As New SqlCommand(sql, cn)
            cmd.CommandTimeout = 120
            Dim p = cmd.Parameters.Add("@id", SqlDbType.Decimal)
            p.Precision = 18
            p.Scale = 0
            p.Value = id
            cmd.Parameters.Add("@max", SqlDbType.BigInt).Value = maxBytes
            cn.Open()
            Using rd = cmd.ExecuteReader(CommandBehavior.SingleRow)
                If Not rd.Read() Then Throw New InvalidOperationException($"Er_Id {id:0} introuvable.")
                Dim len = If(rd.IsDBNull(0), 0L, Convert.ToInt64(rd.GetValue(0)))
                If rd.IsDBNull(1) Then
                    If len > maxBytes Then
                        Throw New InvalidOperationException($"Binaire trop volumineux ({len:N0} octets > MaxBinaryMB).")
                    End If
                    Return New Byte() {}
                End If
                Return DirectCast(rd.GetValue(1), Byte())
            End Using
        End Using
    End Function

    Private Shared Function S(rd As SqlDataReader, i As Integer) As String
        Return If(rd.IsDBNull(i), "", rd.GetString(i))
    End Function

End Class
